// react-hook.js — Runs in Instagram PAGE context (not content script)
// Injected at document_start, BEFORE React loads.
//
// 1. Installs a fake __REACT_DEVTOOLS_GLOBAL_HOOK__ to capture React's fiber tree
// 2. Provides findOne/findMany for traversing the component tree
// 3. Registers task handlers for DM automation (accessible via window.postMessage)
//
// Communication: content.js ↔ react-hook.js via postMessage
//   Content sends:  { type: 'IG_AUTOMATOR_REQUEST', id, task, data }
//   Page responds:  { type: 'IG_AUTOMATOR_RESPONSE', id, success, result, error }

(function () {
  'use strict';

  // =============================================
  // SECTION 1: Utilities
  // =============================================

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  // =============================================
  // SECTION 2: React Fiber Tree Tracker
  // =============================================

  var REACT_TYPE_OF_WORK = {
    CacheComponent: 24,
    ClassComponent: 1,
    ContextConsumer: 9,
    ContextProvider: 10,
    DehydratedSuspenseComponent: 18,
    ForwardRef: 11,
    Fragment: 7,
    FunctionComponent: 0,
    HostComponent: 5,
    HostPortal: 4,
    HostRoot: 3,
    HostHoistable: 26,
    HostSingleton: 27,
    HostText: 6,
    IncompleteClassComponent: 17,
    IndeterminateComponent: 2,
    LazyComponent: 16,
    LegacyHiddenComponent: 23,
    MemoComponent: 14,
    Mode: 8,
    OffscreenComponent: 22,
    Profiler: 12,
    ScopeComponent: 21,
    SimpleMemoComponent: 15,
    SuspenseComponent: 13,
    SuspenseListComponent: 19,
    TracingMarkerComponent: 25,
  };

  function FiberTree() {
    this.fiberToIDMap = new Map();
    this.idToFiberMap = new Map();
    this.uidCounter = 0;
    this._root = null;
    this.cachedDisplayNames = new WeakMap();
  }

  FiberTree.prototype.getUID = function () {
    return ++this.uidCounter;
  };

  FiberTree.prototype.getOrGenerateFiberID = function (fiber) {
    var id = null;

    if (this.fiberToIDMap.has(fiber)) {
      id = this.fiberToIDMap.get(fiber);
    } else {
      var alt = fiber.alternate;
      if (alt && this.fiberToIDMap.has(alt)) {
        id = this.fiberToIDMap.get(alt);
      }
    }

    if (id === null) id = this.getUID();

    if (!this.fiberToIDMap.has(fiber)) {
      this.fiberToIDMap.set(fiber, id);
      this.idToFiberMap.set(id, fiber);
    }

    var alt2 = fiber.alternate;
    if (alt2 && !this.fiberToIDMap.has(alt2)) {
      this.fiberToIDMap.set(alt2, id);
    }

    return id;
  };

  FiberTree.prototype.getTypeSymbol = function (type) {
    var sym = typeof type === 'object' && type !== null ? type.$$typeof : type;
    return typeof sym === 'symbol' ? sym.toString() : sym;
  };

  FiberTree.prototype.resolveFiberType = function (type) {
    var sym = this.getTypeSymbol(type);
    if (sym === 60115 || sym === 'Symbol(react.memo)') return this.resolveFiberType(type.type);
    if (sym === 60112 || sym === 'Symbol(react.forward_ref)') return type.render;
    return type;
  };

  FiberTree.prototype.getDisplayName = function (type, fallback) {
    fallback = fallback || 'Anonymous';
    var cached = this.cachedDisplayNames.get(type);
    if (cached != null) return cached;

    var name = fallback;
    if (typeof type.displayName === 'string') name = type.displayName;
    else if (typeof type.name === 'string' && type.name !== '') name = type.name;

    this.cachedDisplayNames.set(type, name);
    return name;
  };

  FiberTree.prototype.getWrappedDisplayName = function (elementType, resolvedType, wrapper, fallback) {
    return elementType.displayName || (wrapper + '(' + this.getDisplayName(resolvedType, fallback) + ')');
  };

  FiberTree.prototype.getDisplayNameForFiber = function (fiber) {
    var elementType = fiber.elementType;
    var type = fiber.type;
    var tag = fiber.tag;
    var resolved = type;

    if (typeof type === 'object' && type !== null) {
      resolved = this.resolveFiberType(type);
    }

    switch (tag) {
      case REACT_TYPE_OF_WORK.ClassComponent:
      case REACT_TYPE_OF_WORK.IncompleteClassComponent:
      case REACT_TYPE_OF_WORK.FunctionComponent:
      case REACT_TYPE_OF_WORK.IndeterminateComponent:
        return this.getDisplayName(resolved);
      case REACT_TYPE_OF_WORK.ForwardRef:
        return this.getWrappedDisplayName(elementType, resolved, 'ForwardRef', 'Anonymous');
      case REACT_TYPE_OF_WORK.HostRoot:
        return null;
      case REACT_TYPE_OF_WORK.HostComponent:
      case REACT_TYPE_OF_WORK.HostSingleton:
      case REACT_TYPE_OF_WORK.HostHoistable:
        return type;
      case REACT_TYPE_OF_WORK.HostPortal:
      case REACT_TYPE_OF_WORK.HostText:
        return null;
      case REACT_TYPE_OF_WORK.Fragment:
        return 'Fragment';
      case REACT_TYPE_OF_WORK.LazyComponent:
        return 'Lazy';
      case REACT_TYPE_OF_WORK.MemoComponent:
      case REACT_TYPE_OF_WORK.SimpleMemoComponent:
        return this.getWrappedDisplayName(elementType, resolved, 'Memo', 'Anonymous');
      case REACT_TYPE_OF_WORK.SuspenseComponent:
        return 'Suspense';
      case REACT_TYPE_OF_WORK.LegacyHiddenComponent:
        return 'LegacyHidden';
      case REACT_TYPE_OF_WORK.OffscreenComponent:
        return 'Offscreen';
      case REACT_TYPE_OF_WORK.ScopeComponent:
        return 'Scope';
      case REACT_TYPE_OF_WORK.SuspenseListComponent:
        return 'SuspenseList';
      case REACT_TYPE_OF_WORK.Profiler:
        return 'Profiler';
      case REACT_TYPE_OF_WORK.TracingMarkerComponent:
        return 'TracingMarker';
      default:
        var typeSym = this.getTypeSymbol(type);
        switch (typeSym) {
          case 60111:
          case 'Symbol(react.concurrent_mode)':
          case 'Symbol(react.async_mode)':
            return null;
          case 60109:
          case 'Symbol(react.provider)':
            return ((fiber.type._context || fiber.type.context || {}).displayName || 'Context') + '.Provider';
          case 60110:
          case 'Symbol(react.context)':
          case 'Symbol(react.server_context)':
            return ((fiber.type._context || fiber.type || {}).displayName || 'Context') + '.Consumer';
          case 60108:
          case 'Symbol(react.strict_mode)':
            return null;
          case 60114:
          case 'Symbol(react.profiler)':
            return 'Profiler(' + (fiber.memoizedProps && fiber.memoizedProps.id) + ')';
          default:
            return null;
        }
    }
  };

  FiberTree.prototype.mountFiberRecursively = function (fiber, parent, traverseSiblings) {
    var node = fiber;
    while (node !== null) {
      this.getOrGenerateFiberID(node);

      var isSuspense = node.tag === REACT_TYPE_OF_WORK.SuspenseComponent;
      if (isSuspense) {
        if (node.memoizedState !== null) {
          var primary = node.child;
          var fallback = primary ? primary.sibling : null;
          var fallbackChild = fallback ? fallback.child : null;
          if (fallbackChild) this.mountFiberRecursively(fallbackChild, node, true);
        } else {
          var child = null;
          if (node.child !== null) {
            child = REACT_TYPE_OF_WORK.OffscreenComponent === -1 ? node.child : node.child.child;
          }
          if (child) this.mountFiberRecursively(child, node, true);
        }
      } else if (node.child !== null) {
        this.mountFiberRecursively(node.child, node, true);
      }

      node = traverseSiblings ? node.sibling : null;
    }
  };

  FiberTree.prototype.handleCommitFiberRoot = function (root) {
    var current = root.current;
    this._root = current;
    this.getOrGenerateFiberID(current);
    this.mountFiberRecursively(current, null, false);
  };

  // =============================================
  // SECTION 3: Fiber Element Wrapper (for searching the tree)
  // =============================================

  function FiberElement(fiber, tree) {
    this._fiber = fiber;
    this._tree = tree;
  }

  Object.defineProperty(FiberElement.prototype, 'element', {
    get: function () { return this._fiber; },
  });

  FiberElement.prototype.findOne = function (name) {
    var results = this._search(this._fiber, name);
    return results[0] || null;
  };

  FiberElement.prototype.findMany = function (name) {
    return this._search(this._fiber, name);
  };

  FiberElement.prototype._search = function (fiber, name) {
    var results = [];
    if (!fiber) return results;

    var displayName = this._tree.getDisplayNameForFiber(fiber);
    if (displayName && displayName.indexOf(name) > -1) {
      results.push(new FiberElement(fiber, this._tree));
    }

    if (fiber.child) {
      var child = fiber.child;
      while (child) {
        var childResults = this._search(child, name);
        for (var i = 0; i < childResults.length; i++) results.push(childResults[i]);
        child = child.sibling;
      }
    }

    return results;
  };

  // =============================================
  // SECTION 4: Install React DevTools Hook
  // =============================================

  var tree = new FiberTree();

  function installHook(target) {
    if (target.hasOwnProperty('__REACT_DEVTOOLS_GLOBAL_HOOK__')) return;

    var fiberRoots = {};
    var renderers = new Map();
    var listeners = {};

    var hook = {
      rendererInterfaces: new Map(),
      listeners: listeners,
      backends: new Map(),
      renderers: renderers,
      supportsFiber: true,

      inject: function (renderer) {
        var id = renderers.size + 1;
        renderers.set(id, renderer);
        hook._emit('renderer', { id: id, renderer: renderer });
        return id;
      },

      _emit: function (event, data) {
        var fns = listeners[event];
        if (fns) fns.forEach(function (fn) { fn(data); });
      },

      on: function (event, fn) {
        if (!listeners[event]) listeners[event] = [];
        listeners[event].push(fn);
      },

      off: function (event, fn) {
        if (listeners[event]) {
          var idx = listeners[event].indexOf(fn);
          if (idx > -1) listeners[event].splice(idx, 1);
        }
      },

      sub: function (event, fn) {
        hook.on(event, fn);
        return function () { hook.off(event, fn); };
      },

      getFiberRoots: function (rendererId) {
        if (!fiberRoots[rendererId]) fiberRoots[rendererId] = new Set();
        return fiberRoots[rendererId];
      },

      onCommitFiberRoot: function (rendererId, root) {
        var roots = hook.getFiberRoots(rendererId);
        var current = root.current;
        var isUnmounting = current.memoizedState == null || current.memoizedState.element == null;

        if (roots.has(root) && isUnmounting) {
          roots.delete(root);
        } else if (!isUnmounting) {
          roots.add(root);
        }

        try {
          tree.handleCommitFiberRoot(root);
        } catch (e) {
          // Silently handle fiber processing errors
        }
      },

      onCommitFiberUnmount: function () {},
      onPostCommitFiberRoot: function () {},
      checkDCE: function () {},
      setStrictMode: function () {},
      getInternalModuleRanges: function () { return []; },
      registerInternalModuleStart: function () {},
      registerInternalModuleStop: function () {},
    };

    Object.defineProperty(target, '__REACT_DEVTOOLS_GLOBAL_HOOK__', {
      configurable: false,
      enumerable: false,
      get: function () { return hook; },
    });
  }

  installHook(window);

  // =============================================
  // SECTION 4b: Fallback — recover fiber tree from existing React roots
  // =============================================
  // If React loaded before our hook (race condition on extension reload/update),
  // scan the DOM for React internal fiber properties and recover the tree.

  function tryRecoverFiberRoot() {
    if (tree._root) return; // already captured via hook

    // Instagram's root container
    var candidates = document.querySelectorAll('#mount_0_0_0, #react-root, [id^="mount_"]');
    if (candidates.length === 0) {
      // Fallback: try document body's first child
      candidates = document.body ? [document.body] : [];
    }

    for (var c = 0; c < candidates.length; c++) {
      var el = candidates[c];
      var keys = Object.getOwnPropertyNames(el);
      for (var k = 0; k < keys.length; k++) {
        if (keys[k].indexOf('__reactContainer$') === 0 || keys[k].indexOf('__reactFiber$') === 0) {
          var fiber = el[keys[k]];
          // Walk up to the HostRoot
          while (fiber && fiber.return) fiber = fiber.return;
          if (fiber && fiber.stateNode && fiber.stateNode.current) {
            try {
              tree.handleCommitFiberRoot(fiber.stateNode);
              console.log('[IG-DM-Automator] Fiber tree recovered from existing React root (' + tree.fiberToIDMap.size + ' fibers)');
            } catch (e) {
              console.log('[IG-DM-Automator] Fiber recovery error:', e.message);
            }
            return;
          }
        }
      }
    }
  }

  // Try recovery at increasing intervals (1s, 3s, 6s, 10s)
  var recoveryDelays = [1000, 3000, 6000, 10000];
  recoveryDelays.forEach(function (delay) {
    setTimeout(function () { tryRecoverFiberRoot(); }, delay);
  });

  // =============================================
  // SECTION 5: Message Bridge (Page ↔ Content Script)
  // =============================================

  var taskHandlers = {};

  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== 'IG_AUTOMATOR_REQUEST') return;

    var id = event.data.id;
    var task = event.data.task;
    var data = event.data.data || {};
    var handler = taskHandlers[task];

    if (!handler) {
      window.postMessage({ type: 'IG_AUTOMATOR_RESPONSE', id: id, success: false, error: 'Unknown task: ' + task }, '*');
      return;
    }

    Promise.resolve()
      .then(function () { return handler(data); })
      .then(function (result) {
        window.postMessage({ type: 'IG_AUTOMATOR_RESPONSE', id: id, success: true, result: result }, '*');
      })
      .catch(function (err) {
        window.postMessage({ type: 'IG_AUTOMATOR_RESPONSE', id: id, success: false, error: err.message || String(err) }, '*');
      });
  });

  function registerTask(name, handler) {
    taskHandlers[name] = handler;
  }

  // =============================================
  // SECTION 6: Helpers
  // =============================================

  function getRoot() {
    if (!tree._root) return null;
    return new FiberElement(tree._root, tree);
  }

  // Import an Instagram internal module by name.
  // Instagram exposes importNamespace / require as globals.
  function importModule(name, maxRetries) {
    maxRetries = maxRetries || 15;
    var attempt = 0;

    return new Promise(function (resolve, reject) {
      function tryImport() {
        // Try importNamespace (Instagram's primary module loader)
        try {
          if (typeof importNamespace === 'function') {
            var mod = importNamespace(name);
            if (mod) { resolve(mod); return; }
          }
        } catch (e) {}

        // Fallback: try require
        try {
          if (typeof require === 'function') {
            var mod2 = require(name);
            if (mod2) { resolve(mod2); return; }
          }
        } catch (e) {}

        attempt++;
        if (attempt >= maxRetries) {
          reject(new Error('Module "' + name + '" not found after ' + maxRetries + ' retries'));
        } else {
          setTimeout(tryImport, 1000);
        }
      }

      tryImport();
    });
  }

  // =============================================
  // SECTION 7: DM Task Handlers
  // =============================================

  // --- Ping: verify react-hook.js is loaded and tree is ready ---
  registerTask('ping', function () {
    // If tree not captured yet, try recovery on each ping
    if (!tree._root) tryRecoverFiberRoot();
    return { ready: !!tree._root, fiberCount: tree.fiberToIDMap.size };
  });

  // --- Extract thread ID from the active conversation ---
  registerTask('getThreadId', function () {
    // Method 1: URL (most reliable when it works)
    var urlMatch = window.location.pathname.match(/\/direct\/t\/(\d+)/);
    if (urlMatch) return { threadId: urlMatch[1], source: 'url' };

    // Method 2: Search fiber tree for thread-related components
    var root = getRoot();
    if (root) {
      // Look for components that contain thread data in their props
      var componentNames = [
        'IGDSMessageListContainer',
        'IGDMessageList',
        'IGDThreadHeader',
        'IGDSThreadHeader',
        'IGDThreadView',
        'IGDSThreadView',
        'PolarisDirectThreadView',
        'PolarisDirectThread',
      ];

      for (var i = 0; i < componentNames.length; i++) {
        var component = root.findOne(componentNames[i]);
        if (!component) continue;

        // Walk up and check props for threadId, thread_id, or thread.thread_v2_id
        var fiber = component.element;
        var checked = 0;
        while (fiber && checked < 20) {
          var props = fiber.memoizedProps || {};
          if (props.threadId) return { threadId: String(props.threadId), source: 'fiber:' + componentNames[i] };
          if (props.thread_id) return { threadId: String(props.thread_id), source: 'fiber:' + componentNames[i] };
          if (props.threadID) return { threadId: String(props.threadID), source: 'fiber:' + componentNames[i] };
          if (props.thread && props.thread.thread_id) return { threadId: String(props.thread.thread_id), source: 'fiber:' + componentNames[i] };
          if (props.thread && props.thread.thread_v2_id) return { threadId: String(props.thread.thread_v2_id), source: 'fiber:' + componentNames[i] };
          // Check memoizedState for thread info
          var state = fiber.memoizedState;
          while (state) {
            if (state.memoizedState && typeof state.memoizedState === 'object') {
              var s = state.memoizedState;
              if (s.threadId) return { threadId: String(s.threadId), source: 'fiber-state:' + componentNames[i] };
              if (s.thread_id) return { threadId: String(s.thread_id), source: 'fiber-state:' + componentNames[i] };
            }
            state = state.next;
          }
          fiber = fiber.return;
          checked++;
        }
      }

      // Method 3: Look for thread data in any component matching "Thread"
      var threadComponents = root.findMany('Thread');
      for (var t = 0; t < threadComponents.length; t++) {
        var tf = threadComponents[t].element;
        var p = tf.memoizedProps || {};
        if (p.threadId) return { threadId: String(p.threadId), source: 'fiber-search' };
        if (p.thread_id) return { threadId: String(p.thread_id), source: 'fiber-search' };
        if (p.threadID) return { threadId: String(p.threadID), source: 'fiber-search' };
      }
    }

    // Method 4: Check DOM for thread link elements
    var threadLinks = document.querySelectorAll('a[href*="/direct/t/"]');
    if (threadLinks.length > 0) {
      // Get the last one (most likely the active conversation)
      var lastLink = threadLinks[threadLinks.length - 1];
      var linkMatch = lastLink.href.match(/\/direct\/t\/(\d+)/);
      if (linkMatch) return { threadId: linkMatch[1], source: 'dom-link' };
    }

    return { threadId: null, source: 'not_found' };
  });

  // --- Check for notification modal and dismiss ---
  registerTask('checkNotificationModal', function () {
    var root = getRoot();
    if (!root) return false;

    var modal = root.findOne('PolarisNotificationsScreenModal.react');
    if (modal && modal.element && modal.element.memoizedProps && modal.element.memoizedProps.onClose) {
      modal.element.memoizedProps.onClose();
      return sleep(2000).then(function () { return true; });
    }
    return false;
  });

  // --- Detect Instagram 500 error page ---
  registerTask('detectError', function () {
    var root = getRoot();
    if (!root) return false;
    return Boolean(root.findOne('PolarisHttp500UnexpectedErrorPage.react'));
  });

  // --- Click "New Message" dialog button ---
  registerTask('clickDialogButton', function () {
    var root = getRoot();
    if (!root) return Promise.reject(new Error('React tree not ready'));

    // If in a thread view, navigate back to inbox first
    if (location.href.indexOf('instagram.com/direct/t/') > -1) {
      var inboxLink = document.querySelector('[href="/direct/inbox/"]');
      if (inboxLink) {
        inboxLink.click();
        return sleep(2000).then(function () { return tryClickDialogButton(root, 0); });
      }
    }

    return tryClickDialogButton(root, 0);
  });

  function tryClickDialogButton(root, attempt) {
    if (attempt >= 10) return Promise.reject(new Error('New message button not found'));

    // Re-get root on each attempt (tree may have updated)
    root = getRoot();
    if (!root) return sleep(1000).then(function () { return tryClickDialogButton(root, attempt + 1); });

    // Method 1: IGDThreadListNewMessageDialogButton → BaseButton
    var btn1 = root.findOne('IGDThreadListNewMessageDialogButton.react');
    if (btn1) {
      var base = btn1.findOne('BaseButton.react');
      if (base && base.element) {
        var props = base.element.return && base.element.return.memoizedProps;
        if (props && props.onClick) { props.onClick(); return true; }
        props = base.element.memoizedProps;
        if (props && props.onClick) { props.onClick(); return true; }
      }
    }

    // Method 2: IGDThreadListNewMessageDialogEntrypointProvider → CometPressable
    var btn2 = root.findOne('IGDThreadListNewMessageDialogEntrypointProvider');
    if (btn2) {
      var pressable = btn2.findOne('CometPressable.react');
      if (pressable && pressable.element && pressable.element.memoizedProps && pressable.element.memoizedProps.onPress) {
        pressable.element.memoizedProps.onPress();
        return true;
      }
    }

    // Method 3: IGDThreadListNewMessageDialogButton → IGDSIconButton
    var btn3 = root.findOne('IGDThreadListNewMessageDialogButton');
    if (btn3) {
      var icon = btn3.findOne('IGDSIconButton.react');
      if (icon && icon.element && icon.element.memoizedProps && icon.element.memoizedProps.onClick) {
        icon.element.memoizedProps.onClick();
        return true;
      }
    }

    // Method 4: Aria-label fallback (multiple languages)
    var labels = ['New message', 'Nuevo mensaje', 'Nouvelle conversation', 'Neue Nachricht', 'Nova mensagem', 'Nuovo messaggio', 'Nieuw bericht'];
    var selector = labels.map(function (l) { return '[aria-label="' + l + '"]'; }).join(', ');
    var ariaBtn = document.querySelector(selector);
    if (ariaBtn && ariaBtn.parentNode) {
      ariaBtn.parentNode.click();
      return true;
    }

    return sleep(1000).then(function () { return tryClickDialogButton(root, attempt + 1); });
  }

  // --- Enter username in the search dialog ---
  registerTask('enterUsername', function (data) {
    var username = data.username;
    var root = getRoot();
    if (!root) return Promise.reject(new Error('React tree not ready'));

    return waitForDialog(root, 0).then(function () {
      return typeUsername(username);
    });
  });

  function waitForDialog(root, attempt) {
    if (attempt >= 10) return Promise.reject(new Error('New message dialog not found'));
    root = getRoot();
    if (root && root.findOne('IGDThreadListNewMessageDialog.react')) return Promise.resolve();
    return sleep(1000).then(function () { return waitForDialog(root, attempt + 1); });
  }

  function typeUsername(username) {
    var root = getRoot();
    var dialog = root.findOne('IGDThreadListNewMessageDialog.react');
    if (!dialog) return Promise.reject(new Error('Dialog disappeared'));

    // Method 1: Direct onChange
    var listener = dialog.findOne('PolarisDOMListener.react');
    if (listener && listener.element && listener.element.sibling && listener.element.sibling.sibling) {
      var props = listener.element.sibling.sibling.memoizedProps;
      if (props && props.onChange) {
        props.onChange({ target: { value: username } });
        return true;
      }
    }

    // Method 2: TokenField — type char by char
    var tokenField = dialog.findOne('IGDirectSearchUserContainerTokenField');
    if (tokenField) {
      var box = tokenField.findOne('IGDSBox.react');
      if (box) {
        var innerBox = box.findOne('IGDSBox.react');
        if (innerBox && innerBox.element) {
          var el = innerBox.element;
          // Navigate through the fiber tree to find the input element
          var input = el.child && el.child.child && el.child.child.child && el.child.child.child.child;
          var inputSibling = input && input.sibling;
          if (inputSibling && inputSibling.memoizedProps && inputSibling.memoizedProps.onChange) {
            return typeCharByChar(inputSibling, username, 0);
          }
        }
      }
    }

    // Method 3: Try to find any input in the dialog via DOM
    var dialogEl = dialog.element && dialog.element.stateNode;
    if (!dialogEl) {
      // Try to find dialog DOM element by role
      dialogEl = document.querySelector('div[role="dialog"]');
    }
    if (dialogEl) {
      var inputEl = dialogEl.querySelector('input[type="text"], input[name="queryBox"]');
      if (inputEl) {
        var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(inputEl, username);
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }
    }

    return Promise.reject(new Error('Search input not found in dialog'));
  }

  function typeCharByChar(inputFiber, username, index) {
    if (index >= username.length) return Promise.resolve(true);
    inputFiber.memoizedProps.onChange({ target: { value: username.substring(0, index + 1) } });
    var delay = 50 + Math.random() * 100;
    return sleep(delay).then(function () { return typeCharByChar(inputFiber, username, index + 1); });
  }

  // --- Get search results ---
  registerTask('findSearchResult', function () {
    var root = getRoot();
    if (!root) return [];

    var list = root.findOne('IGDAWContactSearchResultList.react');
    if (!list) return [];

    // Method 1: IGDContactSearchResult
    var results = list.findMany('IGDContactSearchResult.react');
    if (results.length) {
      return results.map(function (r) { return r.element.memoizedProps.candidate; });
    }

    // Method 2: IGDSupershareContactSearchResult
    var results2 = list.findMany('IGDSupershareContactSearchResult.react');
    if (results2.length) {
      return results2.map(function (r) { return r.element.memoizedProps.candidate; });
    }

    // Method 3: children array fallback
    var box = list.findOne('IGDSBox.react');
    if (box) {
      var innerBox = box.findOne('IGDSBox.react');
      if (innerBox && innerBox.element && innerBox.element.return && innerBox.element.return.memoizedProps) {
        var children = innerBox.element.return.memoizedProps.children;
        if (children && children[0] && Array.isArray(children[0])) {
          return children[0]
            .filter(function (c) { return c && c.props && c.props.candidate; })
            .map(function (c) { return c.props.candidate; });
        }
      }
    }

    return [];
  });

  // --- Click on a user in search results ---
  registerTask('clickOnUser', function (data) {
    var threadId = data.threadId;
    var userId = data.userId;
    var root = getRoot();
    if (!root) return Promise.reject(new Error('React tree not ready'));

    var list = root.findOne('IGDAWContactSearchResultList.react');
    if (!list) return Promise.reject(new Error('Search result list not found'));

    // Try IGDContactSearchResult, then IGDSupershareContactSearchResult
    var results = list.findMany('IGDContactSearchResult.react');
    if (!results.length) results = list.findMany('IGDSupershareContactSearchResult.react');

    for (var i = 0; i < results.length; i++) {
      var r = results[i];
      var candidate = r.element.memoizedProps && r.element.memoizedProps.candidate && r.element.memoizedProps.candidate.candidate;
      if (!candidate) continue;

      var matches = (threadId && candidate.id === threadId) || (userId && String(candidate.igid) === String(userId));
      if (!matches) continue;

      // Try BaseButton
      var base = r.findOne('BaseButton.react');
      if (base && base.element && base.element.memoizedProps && base.element.memoizedProps.onClick) {
        base.element.memoizedProps.onClick();
        return true;
      }

      // Try WebPressable
      var web = r.findOne('WebPressable.react');
      if (web && web.element && web.element.memoizedProps && web.element.memoizedProps.onClick) {
        web.element.memoizedProps.onClick();
        return true;
      }

      // Try CometPressable
      var comet = r.findOne('CometPressable.react');
      if (comet && comet.element && comet.element.memoizedProps && comet.element.memoizedProps.onPress) {
        comet.element.memoizedProps.onPress();
        return true;
      }
    }

    // Fallback: children array
    var box = list.findOne('IGDSBox.react');
    if (box) {
      var innerBox = box.findOne('IGDSBox.react');
      if (innerBox && innerBox.element && innerBox.element.return && innerBox.element.return.memoizedProps) {
        var children = innerBox.element.return.memoizedProps.children;
        if (children && children[0] && Array.isArray(children[0])) {
          for (var j = 0; j < children[0].length; j++) {
            var child = children[0][j];
            if (!child || !child.props || !child.props.candidate) continue;
            var c = child.props.candidate.candidate || child.props.candidate;
            var m = (threadId && c.id === threadId) || (userId && String(c.igid) === String(userId));
            if (m && child.props.onPress) {
              child.props.onPress();
              return true;
            }
          }
        }
      }
    }

    return Promise.reject(new Error('User not found in search results'));
  });

  // --- Click the first search result (when exact match not needed) ---
  registerTask('clickFirstResult', function () {
    var root = getRoot();
    if (!root) return Promise.reject(new Error('React tree not ready'));

    var list = root.findOne('IGDAWContactSearchResultList.react');
    if (!list) return Promise.reject(new Error('Search result list not found'));

    var results = list.findMany('IGDContactSearchResult.react');
    if (!results.length) results = list.findMany('IGDSupershareContactSearchResult.react');

    if (results.length > 0) {
      var r = results[0];
      var base = r.findOne('BaseButton.react');
      if (base && base.element && base.element.memoizedProps && base.element.memoizedProps.onClick) {
        base.element.memoizedProps.onClick();
        return true;
      }
      var web = r.findOne('WebPressable.react');
      if (web && web.element && web.element.memoizedProps && web.element.memoizedProps.onClick) {
        web.element.memoizedProps.onClick();
        return true;
      }
      var comet = r.findOne('CometPressable.react');
      if (comet && comet.element && comet.element.memoizedProps && comet.element.memoizedProps.onPress) {
        comet.element.memoizedProps.onPress();
        return true;
      }
    }

    // Fallback: children array
    var box = list.findOne('IGDSBox.react');
    if (box) {
      var innerBox = box.findOne('IGDSBox.react');
      if (innerBox && innerBox.element && innerBox.element.return && innerBox.element.return.memoizedProps) {
        var children = innerBox.element.return.memoizedProps.children;
        if (children && children[0] && Array.isArray(children[0]) && children[0].length > 0) {
          var firstChild = children[0][0];
          if (firstChild && firstChild.props && firstChild.props.onPress) {
            firstChild.props.onPress();
            return true;
          }
        }
      }
    }

    return Promise.reject(new Error('No search results to click'));
  });

  // --- Click "Chat" / "Next" button to open conversation ---
  registerTask('clickChat', function () {
    return tryClickChat(0);
  });

  function tryClickChat(attempt) {
    if (attempt >= 10) return Promise.reject(new Error('Chat/Next button not found'));

    var root = getRoot();
    if (!root) return sleep(1000).then(function () { return tryClickChat(attempt + 1); });

    var dialog = root.findOne('IGDThreadListNewMessageDialog.react');
    if (dialog) {
      // Find the last CometPressable (usually the "Chat" or "Next" button)
      var pressables = dialog.findMany('CometPressable.react');
      if (pressables.length > 0) {
        var last = pressables[pressables.length - 1];
        if (last.element && last.element.memoizedProps && last.element.memoizedProps.onPress) {
          last.element.memoizedProps.onPress();
          return true;
        }
      }

      // Try IGDSBox approach
      var boxes = dialog.findMany('IGDSBox.react');
      if (boxes.length > 0) {
        var lastBox = boxes[boxes.length - 1];
        var p = lastBox.findOne('CometPressable.react');
        if (p && p.element && p.element.memoizedProps && p.element.memoizedProps.onPress) {
          p.element.memoizedProps.onPress();
          return true;
        }
      }
    }

    return sleep(1000).then(function () { return tryClickChat(attempt + 1); });
  }

  // --- Close the new message dialog ---
  registerTask('closeDialog', function () {
    var root = getRoot();
    if (!root) return false;

    var dialog = root.findOne('IGDThreadListNewMessageDialog.react');
    if (dialog && dialog.element && dialog.element.memoizedProps && dialog.element.memoizedProps.onClose) {
      dialog.element.memoizedProps.onClose();
      return true;
    }

    // Fallback: close any IGDSDialog
    var igdsDialog = root.findOne('IGDSDialog.react');
    if (igdsDialog && igdsDialog.element && igdsDialog.element.memoizedProps && igdsDialog.element.memoizedProps.onClose) {
      igdsDialog.element.memoizedProps.onClose();
      return true;
    }

    return false;
  });

  // --- Wait for message input to be ready (called from content script) ---
  // Only requires contenteditable div to exist — enterSymbol/sendMessage have DOM fallbacks
  // if __lexicalEditor is not yet attached.
  registerTask('waitForEditor', function () {
    var input = document.querySelector('div[contenteditable="true"]');
    if (input) return true;
    // Fallback: check for role="textbox"
    var textbox = document.querySelector('[role="textbox"][contenteditable]');
    if (textbox) return true;
    return false;
  });

  // --- Type an entire message into the input (single call, no round-trips) ---
  // Primary: Lexical editor.update() + $insertNodes — works WITHOUT window focus.
  // Fallback: document.execCommand (needs window focus, used when Lexical unavailable).

  function typingDelay(char) {
    var min, max;
    if (char === ' ' || char === '\n') { min = 80; max = 180; }
    else if ('.!?,;:'.indexOf(char) > -1) { min = 120; max = 250; }
    else { min = 30; max = 90; }
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function queryInput() {
    return document.querySelector('div[contenteditable="true"]')
      || document.querySelector('[role="textbox"][contenteditable]');
  }

  // Lexical API typing — works in background tabs (no window focus required)
  function typeViaLexical(input, message, Lexical, index) {
    if (index >= message.length) return Promise.resolve({ mode: 'lexical' });

    var currentInput = queryInput();
    if (currentInput && currentInput.__lexicalEditor) input = currentInput;

    var char = message[index];

    try {
      // focus() sets document.activeElement (doesn't steal window focus)
      input.focus();
      input.__lexicalEditor.update(function () {
        // Ensure Lexical has an active selection
        var selection = Lexical.$getSelection ? Lexical.$getSelection() : null;
        if (!selection && Lexical.$getRoot) {
          Lexical.$getRoot().selectEnd();
          selection = Lexical.$getSelection ? Lexical.$getSelection() : null;
        }

        if (char.charCodeAt(0) === 13) {
          if (selection && selection.insertLineBreak) {
            selection.insertLineBreak();
          } else {
            Lexical.$insertNodes([Lexical.$createLineBreakNode()]);
          }
        } else {
          if (selection && selection.insertText) {
            selection.insertText(char);
          } else {
            Lexical.$insertNodes([Lexical.$createTextNode(char)]);
          }
        }
      });
    } catch (e) {
      console.log('[enterFullMessage] Lexical error at char ' + index + ':', e.message);
      // Switch to DOM fallback for remaining characters
      return typeViaDom(input, message, index);
    }

    return sleep(typingDelay(char)).then(function () {
      return typeViaLexical(input, message, Lexical, index + 1);
    });
  }

  // DOM typing via execCommand — requires window focus (fallback)
  function typeViaDom(input, message, index) {
    if (index >= message.length) return Promise.resolve({ mode: 'dom' });

    var currentInput = queryInput();
    if (currentInput) input = currentInput;

    var char = message[index];

    try {
      input.focus();
      if (char.charCodeAt(0) === 13) {
        input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
        input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
      } else {
        document.execCommand('insertText', false, char);
      }
    } catch (e) {
      console.log('[enterFullMessage] DOM error at char ' + index + ':', e.message);
    }

    return sleep(typingDelay(char)).then(function () {
      return typeViaDom(input, message, index + 1);
    });
  }

  registerTask('enterFullMessage', function (data) {
    var message = data.message;
    if (!message) return Promise.reject(new Error('No message provided'));

    var input = queryInput();
    if (!input) return Promise.reject(new Error('Contenteditable input not found'));

    // Prefer Lexical API — works without window focus (background-tab safe)
    if (input.__lexicalEditor) {
      return importModule('Lexical', 5)
        .then(function (Lexical) {
          console.log('[enterFullMessage] Using Lexical API (' + message.length + ' chars, no focus required)');
          return typeViaLexical(input, message, Lexical, 0);
        })
        .catch(function (err) {
          console.log('[enterFullMessage] Lexical import failed, using DOM fallback:', err.message);
          return typeViaDom(input, message, 0);
        });
    }

    // No Lexical editor — DOM fallback (needs window focus)
    console.log('[enterFullMessage] No Lexical editor, using DOM (' + message.length + ' chars)');
    return typeViaDom(input, message, 0);
  });

  // --- Type a character into the message input via Lexical editor ---
  registerTask('enterSymbol', function (data) {
    var symbol = data.symbol;

    return new Promise(function (resolve, reject) {
      var timeout = setTimeout(function () { reject(new Error('enterSymbol stuck')); }, 5000);

      var input = document.querySelector('div[contenteditable="true"]')
        || document.querySelector('[role="textbox"][contenteditable]');
      if (!input) {
        clearTimeout(timeout);
        reject(new Error('Contenteditable input not found'));
        return;
      }

      // If Lexical editor is not attached, use DOM fallback
      if (!input.__lexicalEditor) {
        clearTimeout(timeout);
        input.focus();
        if (symbol.charCodeAt(0) === 13) {
          // Line break — insert via Enter key without sending
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
          input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
        } else {
          document.execCommand('insertText', false, symbol);
        }
        resolve(true);
        return;
      }

      importModule('Lexical', 5)
        .then(function (Lexical) {
          input.__lexicalEditor.focus(function () {
            input.__lexicalEditor.update(function () {
              try {
                var node = symbol.charCodeAt(0) === 13
                  ? Lexical.$createLineBreakNode()
                  : Lexical.$createTextNode(symbol);
                Lexical.$insertNodes([node]);
                clearTimeout(timeout);
                resolve(true);
              } catch (e) {
                clearTimeout(timeout);
                // Lexical update failed, try DOM fallback
                input.focus();
                document.execCommand('insertText', false, symbol);
                resolve(true);
              }
            });
          });
        })
        .catch(function (e) {
          clearTimeout(timeout);
          // Lexical module not available, try DOM fallback
          input.focus();
          if (symbol.charCodeAt(0) === 13) {
            input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
            input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true, shiftKey: true }));
          } else {
            document.execCommand('insertText', false, symbol);
          }
          resolve(true);
        });
    });
  });

  // --- Send message by dispatching Enter key command ---
  registerTask('sendMessage', function () {
    var input = document.querySelector('div[contenteditable="true"]')
      || document.querySelector('[role="textbox"][contenteditable]');
    if (!input) {
      // Last resort: try clicking the send button
      return Promise.resolve(clickSendButton());
    }

    function dispatchEnterDOM() {
      input.focus();
      var keyEvent = new KeyboardEvent('keydown', {
        bubbles: true,
        cancelable: true,
        key: 'Enter',
        keyCode: 13,
        which: 13,
        charCode: 13,
        shiftKey: false,
        ctrlKey: false,
        metaKey: false,
      });
      input.dispatchEvent(keyEvent);
      return true;
    }

    // If no Lexical editor, use DOM fallback directly
    if (!input.__lexicalEditor) {
      dispatchEnterDOM();
      // Also try send button as backup
      return sleep(500).then(function () {
        return clickSendButton() || true;
      });
    }

    return importModule('Lexical', 5)
      .then(function (Lexical) {
        var keyEvent = new KeyboardEvent('keydown', {
          bubbles: true,
          cancelable: true,
          key: 'Enter',
          keyCode: 13,
          which: 13,
          charCode: 13,
          shiftKey: false,
          ctrlKey: false,
          metaKey: false,
        });

        input.__lexicalEditor.dispatchCommand(Lexical.KEY_ENTER_COMMAND, keyEvent);
        return true;
      })
      .catch(function () {
        // Lexical module not available, fall back to DOM Enter key
        dispatchEnterDOM();
        return sleep(500).then(function () {
          return clickSendButton() || true;
        });
      });
  });

  // Helper: click the Send button as a fallback
  function clickSendButton() {
    // Instagram's send button: div[role="button"] that is enabled
    var btn = document.querySelector('div[role="button"][tabindex="0"]:not([aria-disabled="true"])');
    if (btn) {
      btn.click();
      return true;
    }
    // Try aria-label based selectors
    var labels = ['Send', 'Enviar', 'Envoyer', 'Senden', 'Invia', 'Verzenden'];
    for (var i = 0; i < labels.length; i++) {
      var sendBtn = document.querySelector('[aria-label="' + labels[i] + '"]');
      if (sendBtn) {
        sendBtn.click();
        return true;
      }
    }
    return false;
  }

  // --- Check if message input is empty (= message was sent successfully) ---
  registerTask('isInputEmpty', function () {
    var input = document.querySelector('div[contenteditable="true"]')
      || document.querySelector('[role="textbox"][contenteditable]');
    if (!input) return true;

    // Check Lexical internal state
    if (input.__lexicalEditor) {
      try {
        var text = input.__lexicalEditor.getEditorState().read(function () {
          var rootNode = input.__lexicalEditor.getEditorState()._nodeMap.get('root');
          return rootNode ? rootNode.getTextContent() : '';
        });
        return (text || '').trim() === '';
      } catch (e) {}
    }

    // Fallback: check DOM textContent
    return (input.textContent || '').trim() === '';
  });

  // --- Get current user info from Redux store ---
  registerTask('getUser', function () {
    var root = getRoot();
    if (!root) return Promise.reject(new Error('React tree not ready'));

    var wrapper = root.findOne('PolarisAppWrapper.react');
    if (!wrapper) return Promise.reject(new Error('PolarisAppWrapper not found'));

    var store = wrapper.element.memoizedProps && wrapper.element.memoizedProps.store;
    if (!store || !store.getState) return Promise.reject(new Error('Redux store not found'));

    var state = store.getState();
    var viewerId = state.users && state.users.viewerId;
    if (!viewerId) return Promise.reject(new Error('No viewerId'));

    var users = state.users.users;
    if (users && users.toJSON) users = users.toJSON();
    if (!users) return Promise.reject(new Error('No users in state'));

    var user = users[viewerId];
    if (!user) return Promise.reject(new Error('Current user not found'));

    return user;
  });

  // --- Get messages from current open thread ---
  registerTask('getMessages', function () {
    return getMessagesWithRetry(0);
  });

  function getMessagesWithRetry(attempt) {
    if (attempt >= 15) return [];

    var root = getRoot();
    if (!root) return sleep(1000).then(function () { return getMessagesWithRetry(attempt + 1); });

    var messages = root.findMany('MWPBaseMessage.react');
    if (messages.length) {
      return messages.map(function (m) {
        var msg = m.element.memoizedProps && m.element.memoizedProps.message;
        return { senderId: msg && msg.senderId, text: msg && msg.text };
      });
    }

    return sleep(1000).then(function () { return getMessagesWithRetry(attempt + 1); });
  }

  // ============================================
  // POST COMMENTING — profile page interactions
  // ============================================

  // --- Get post thumbnails from profile grid ---
  registerTask('getPostGrid', function () {
    // Profile page: post links are a[href*="/p/"] or a[href*="/reel/"]
    // No <article> wrapper — search the whole page
    var links = document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]');
    var posts = [];
    for (var i = 0; i < links.length; i++) {
      posts.push({
        href: links[i].getAttribute('href'),
        index: i,
      });
    }
    return { posts: posts, count: posts.length };
  });

  // --- Click a post by index from the grid ---
  registerTask('clickPost', function (data) {
    var index = data.index || 0;
    var links = document.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]');
    if (links.length === 0) return Promise.reject(new Error('No post links found on profile page'));
    if (index >= links.length) return Promise.reject(new Error('Post index ' + index + ' out of range (' + links.length + ' posts)'));

    var link = links[index];
    link.click();
    console.log('[CommentPost] Clicked post at index ' + index + ': ' + link.getAttribute('href'));
    return true;
  });

  // --- Focus the comment input inside the post modal ---
  registerTask('focusCommentInput', function () {
    // Post modal: look for the comment textarea or contenteditable inside a dialog
    var dialog = document.querySelector('div[role="dialog"]');
    var searchRoot = dialog || document;

    // Instagram comment input is usually a textarea with placeholder "Add a comment..."
    // or a contenteditable inside the post modal
    var textarea = searchRoot.querySelector('textarea[aria-label], textarea[placeholder]');
    if (textarea) {
      textarea.focus();
      textarea.click();
      console.log('[CommentPost] Focused textarea comment input');
      return { type: 'textarea', found: true };
    }

    // Fallback: contenteditable comment input
    var editable = searchRoot.querySelector('div[contenteditable="true"][role="textbox"]');
    if (editable) {
      editable.focus();
      editable.click();
      console.log('[CommentPost] Focused contenteditable comment input');
      return { type: 'contenteditable', found: true };
    }

    return { found: false };
  });

  // --- Type into the comment input (handles both textarea and contenteditable) ---
  registerTask('typeComment', function (data) {
    var comment = data.comment;
    if (!comment) return Promise.reject(new Error('No comment provided'));

    var dialog = document.querySelector('div[role="dialog"]');
    var searchRoot = dialog || document;

    // Try textarea first (most common for IG comments)
    var textarea = searchRoot.querySelector('textarea[aria-label], textarea[placeholder]');
    if (textarea) {
      textarea.focus();
      // Instagram textareas need native input simulation
      var nativeSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, 'value'
      ).set;
      nativeSetter.call(textarea, comment);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[CommentPost] Typed ' + comment.length + ' chars into textarea');
      return { typed: true, type: 'textarea' };
    }

    // Fallback: contenteditable (reuse enterFullMessage logic)
    var editable = searchRoot.querySelector('div[contenteditable="true"][role="textbox"]');
    if (editable) {
      editable.focus();
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, comment);
      console.log('[CommentPost] Typed ' + comment.length + ' chars into contenteditable');
      return { typed: true, type: 'contenteditable' };
    }

    return Promise.reject(new Error('No comment input found in post modal'));
  });

  // --- Click the "Post" submit button inside the post modal ---
  registerTask('clickPostButton', function () {
    var dialog = document.querySelector('div[role="dialog"]');
    var searchRoot = dialog || document;

    // Find the form wrapping the comment input
    var form = searchRoot.querySelector('form[method="POST"]');
    if (form) {
      // The "Post" button is a div[role="button"] inside the form, containing <span>Post</span>
      var buttons = form.querySelectorAll('div[role="button"]');
      for (var i = 0; i < buttons.length; i++) {
        var text = (buttons[i].textContent || '').trim();
        if (text === 'Post' || text === 'Publicar' || text === 'Publier' || text === 'Posten' || text === 'Pubblica') {
          buttons[i].click();
          console.log('[CommentPost] Clicked Post button');
          return { clicked: true };
        }
      }
    }

    // Fallback: find any button-like element with "Post" text in the dialog
    var allButtons = searchRoot.querySelectorAll('div[role="button"], button');
    for (var j = 0; j < allButtons.length; j++) {
      var btnText = (allButtons[j].textContent || '').trim();
      if (btnText === 'Post' || btnText === 'Publicar' || btnText === 'Publier' || btnText === 'Posten' || btnText === 'Pubblica') {
        allButtons[j].click();
        console.log('[CommentPost] Clicked Post button (fallback)');
        return { clicked: true };
      }
    }

    return { clicked: false };
  });

  console.log('[IG-DM-Automator] React hook installed, waiting for React to load...');
})();
