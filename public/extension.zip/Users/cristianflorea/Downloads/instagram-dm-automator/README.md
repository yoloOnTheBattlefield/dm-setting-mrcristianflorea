# Instagram DM Automation - MVP

A minimal viable product Chrome extension for automating Instagram direct messages with backend integration.

## ⚠️ IMPORTANT DISCLAIMER

This tool is for **educational purposes only**. Automated messaging on Instagram violates their Terms of Service and may result in:
- Account suspension or permanent ban
- IP blocking
- Legal action in some jurisdictions

Use at your own risk. The developers are not responsible for any account actions taken by Instagram.

---

## 🎯 Features

- ✅ Send automated DMs to Instagram users
- ✅ Backend integration for task management
- ✅ Manual message sending via popup
- ✅ Task queue system
- ✅ Logging and statistics
- ✅ Configurable backend URL and API key
- ✅ Human-like typing delays
- ✅ Error handling and retry logic

---

## 📋 Prerequisites

- **Node.js** 14+ (for backend)
- **Chrome Browser** (for extension)
- **Instagram Account** (obviously)
- Basic knowledge of JavaScript

---

## 🚀 Quick Start

### Step 1: Set Up the Backend

```bash
# Navigate to the extension directory
cd instagram-dm-automator

# Install dependencies
npm install

# Start the backend server
npm start
```

The backend will run on `http://localhost:3000`

**Default API Key:** `your-secret-key-123`

### Step 2: Install the Chrome Extension

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top right)
3. Click **Load unpacked**
4. Select the `instagram-dm-automator` folder
5. The extension icon should appear in your toolbar

### Step 3: Configure the Extension

1. Click the extension icon in Chrome toolbar
2. Enter your backend URL: `http://localhost:3000/api`
3. Enter your API key: `your-secret-key-123`
4. Click **Save Configuration**

### Step 4: Test It Out

**Option A: Manual Send**
1. Open Instagram in Chrome
2. Click the extension icon
3. Enter a username and message
4. Click **Send Now**

**Option B: Backend Tasks**
1. Create a task using the API (see examples below)
2. Open Instagram
3. Click **Check for Tasks** in the extension popup

---

## 🏗️ Architecture

```
┌─────────────────┐
│  Chrome         │
│  Extension      │
│  (Frontend)     │
└────────┬────────┘
         │
         │ HTTP Requests
         │ (Tasks, Logs, Status)
         │
         ▼
┌─────────────────┐
│  Node.js/       │
│  Express        │
│  Backend        │
└────────┬────────┘
         │
         │ Store/Retrieve
         │
         ▼
┌─────────────────┐
│  Database       │
│  (Tasks, Logs,  │
│   Statistics)   │
└─────────────────┘
```

### Component Breakdown

**Extension Components:**
- `manifest.json` - Extension configuration
- `background.js` - Service worker (handles backend communication)
- `content.js` - Runs on Instagram pages (performs automation)
- `popup.html/js` - User interface

**Backend:**
- `backend-example.js` - REST API server
- In-memory storage (replace with database for production)

---

## 🔌 API Documentation

### Authentication

All requests require an API key in the Authorization header:

```bash
Authorization: Bearer your-secret-key-123
```

### Endpoints

#### 1. Get Next Task
```http
GET /api/tasks/next
```

Returns the next pending task for the authenticated user.

**Response:**
```json
{
  "id": "task_123",
  "type": "send_dm",
  "target": "username",
  "message": "Hi {{username}}!",
  "status": "pending"
}
```

#### 2. Create Task
```http
POST /api/tasks
Content-Type: application/json

{
  "type": "send_dm",
  "target": "example_user",
  "message": "Hi {{username}}, this is a message!"
}
```

**Response:**
```json
{
  "id": "task_xyz",
  "userId": "user1",
  "type": "send_dm",
  "target": "example_user",
  "message": "Hi {{username}}, this is a message!",
  "status": "pending",
  "createdAt": "2024-02-10T12:00:00.000Z"
}
```

#### 3. Complete Task
```http
POST /api/tasks/:taskId/complete
Content-Type: application/json

{
  "result": {
    "success": true,
    "username": "example_user"
  }
}
```

#### 4. Mark Task Failed
```http
POST /api/tasks/:taskId/failed
Content-Type: application/json

{
  "error": "Message button not found"
}
```

#### 5. Get All Tasks
```http
GET /api/tasks
```

**Response:**
```json
{
  "pending": [...],
  "completed": [...],
  "failed": [...]
}
```

#### 6. Send Log
```http
POST /api/logs
Content-Type: application/json

{
  "event": "task_started",
  "taskId": "task_123",
  "data": {}
}
```

#### 7. Get Logs
```http
GET /api/logs
```

---

## 💻 Usage Examples

### Creating Tasks via API

**Using cURL:**
```bash
curl -X POST http://localhost:3000/api/tasks \
  -H "Authorization: Bearer your-secret-key-123" \
  -H "Content-Type: application/json" \
  -d '{
    "type": "send_dm",
    "target": "example_user",
    "message": "Hi {{username}}, check out our product!"
  }'
```

**Using JavaScript:**
```javascript
const createTask = async () => {
  const response = await fetch('http://localhost:3000/api/tasks', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer your-secret-key-123',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      type: 'send_dm',
      target: 'example_user',
      message: 'Hi {{username}}, how are you?'
    })
  });
  
  const task = await response.json();
  console.log('Created task:', task);
};
```

**Using Python:**
```python
import requests

response = requests.post(
    'http://localhost:3000/api/tasks',
    headers={
        'Authorization': 'Bearer your-secret-key-123',
        'Content-Type': 'application/json'
    },
    json={
        'type': 'send_dm',
        'target': 'example_user',
        'message': 'Hi {{username}}!'
    }
)

print(response.json())
```

### Message Templates

Use template variables for personalization:

- `{{username}}` - Instagram username
- `{{firstName}}` - First name (if available)
- `{{name}}` - Full name (if available)

**Example:**
```json
{
  "message": "Hi {{username}}, I noticed you're into photography. Check out our new lens!"
}
```

---

## 🛠️ Customization

### Adding New Task Types

1. **Define the task type in content.js:**
```javascript
switch (task.type) {
  case 'send_dm':
    result = await automator.sendDirectMessage(task.target, task.message);
    break;
    
  case 'follow_user':  // NEW
    result = await automator.followUser(task.target);
    break;
}
```

2. **Implement the method:**
```javascript
class InstagramAutomator {
  async followUser(username) {
    // Your implementation
  }
}
```

### Changing Delays

Edit the CONFIG object in `content.js`:

```javascript
const CONFIG = {
  TYPING_DELAY: 100,        // ms between keystrokes
  WAIT_AFTER_CLICK: 1000,   // ms after clicking
  MAX_RETRIES: 3,
  TIMEOUT: 30000
};
```

### Adding Database Support

Replace the in-memory storage in `backend-example.js` with a real database:

**Example with MongoDB:**
```javascript
const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  userId: String,
  type: String,
  target: String,
  message: String,
  status: String,
  createdAt: Date
});

const Task = mongoose.model('Task', TaskSchema);

// Replace tasks array
app.get('/api/tasks/next', authenticate, async (req, res) => {
  const task = await Task.findOne({
    userId: req.user.userId,
    status: 'pending'
  });
  
  if (task) {
    task.status = 'in_progress';
    await task.save();
  }
  
  res.json(task);
});
```

---

## 🔒 Security Best Practices

1. **Never commit API keys** - Use environment variables
2. **Use HTTPS** in production
3. **Implement rate limiting** to prevent abuse
4. **Hash API keys** - Don't store them in plain text
5. **Add request validation** - Sanitize all inputs
6. **Use JWT tokens** instead of static API keys
7. **Monitor for suspicious activity**

### Example Environment Variables

Create `.env` file:
```
PORT=3000
API_KEY=your-secret-key-here
DATABASE_URL=mongodb://localhost/instagram-dm
```

Update backend:
```javascript
require('dotenv').config();

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY;
```

---

## 📊 Monitoring & Debugging

### View Logs in Chrome

1. Right-click extension icon → **Inspect popup**
2. Check Console tab for errors
3. Use **Network** tab to see API calls

### Backend Logs

The backend logs all events to console:
```
✅ Added sample task for testing
📡 Assigned task task_123 to extension
✅ Task task_123 completed successfully
```

### Common Issues

**Issue:** Extension not connecting to backend
- Check CORS is enabled
- Verify backend URL is correct
- Check API key is valid

**Issue:** Instagram not detecting elements
- Instagram frequently changes their DOM structure
- Update selectors in `content.js`
- Check browser console for errors

**Issue:** Messages not sending
- Ensure you're on Instagram when clicking "Send"
- Check you're logged into Instagram
- Verify target username exists

---

## 📈 Scaling to Production

### 1. Use a Real Database
- PostgreSQL, MongoDB, or MySQL
- Add indexes for performance
- Implement data retention policies

### 2. Add Queue System
- Use Redis or RabbitMQ
- Implement job priorities
- Add retry mechanisms

### 3. Deploy Backend
- Use services like:
  - Heroku
  - AWS Lambda
  - DigitalOcean
  - Vercel (for serverless)

### 4. Implement User Management
- Multi-user support
- User authentication (OAuth, JWT)
- Usage limits per user
- Billing integration

### 5. Add Analytics
- Track success rates
- Monitor response times
- User engagement metrics
- Error tracking (Sentry, LogRocket)

---

## 🧪 Testing

### Manual Testing Checklist

- [ ] Extension installs without errors
- [ ] Configuration saves correctly
- [ ] Backend connection works
- [ ] Manual send works on Instagram
- [ ] Tasks fetched from backend
- [ ] Tasks complete successfully
- [ ] Failed tasks reported correctly
- [ ] Logs sent to backend
- [ ] Statistics update properly

### Automated Testing

Add tests for backend:

```javascript
// tests/api.test.js
const request = require('supertest');
const app = require('../backend-example');

describe('Tasks API', () => {
  test('GET /api/tasks/next requires auth', async () => {
    const response = await request(app)
      .get('/api/tasks/next');
    
    expect(response.status).toBe(401);
  });
  
  test('POST /api/tasks creates task', async () => {
    const response = await request(app)
      .post('/api/tasks')
      .set('Authorization', 'Bearer your-secret-key-123')
      .send({
        type: 'send_dm',
        target: 'test_user',
        message: 'Test'
      });
    
    expect(response.status).toBe(200);
    expect(response.body.id).toBeDefined();
  });
});
```

---

## 📝 File Structure

```
instagram-dm-automator/
├── manifest.json          # Extension configuration
├── background.js          # Service worker
├── content.js            # Instagram automation logic
├── popup.html            # Extension popup UI
├── popup.js              # Popup logic
├── backend-example.js    # Backend API server
├── package.json          # Node.js dependencies
├── README.md             # This file
└── icons/                # Extension icons (create these)
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## 🎨 Creating Icons

You'll need to create 3 icon sizes. Here's a simple SVG you can convert:

```svg
<svg width="128" height="128" xmlns="http://www.w3.org/2000/svg">
  <rect width="128" height="128" rx="20" fill="#667eea"/>
  <text x="64" y="80" font-size="60" text-anchor="middle" fill="white">📨</text>
</svg>
```

Use online tools like:
- https://www.iloveimg.com/resize-image/resize-svg
- https://convertio.co/svg-png/

---

## 🤝 Contributing

This is an MVP. Here are ways to improve it:

1. **Better Instagram DOM detection** - More robust selectors
2. **Batch messaging** - Send to multiple users at once
3. **Schedule tasks** - Time-based automation
4. **A/B testing** - Test different message templates
5. **Analytics dashboard** - Web interface to view stats
6. **Response detection** - Monitor for replies
7. **Media support** - Send images/videos
8. **Follower scraping** - Get lists of followers
9. **Rate limiting** - Respect Instagram's limits

---

## 📄 License

MIT License - Use at your own risk

---

## 🙏 Acknowledgments

This project is for **educational purposes** to demonstrate:
- Chrome extension development
- Backend API integration
- Web automation techniques
- Task queue systems

**Do not use for spam or malicious purposes.**

---

## 📞 Support

For issues and questions:
1. Check the console logs (browser and backend)
2. Verify Instagram hasn't changed their DOM structure
3. Ensure backend is running and accessible
4. Check API key is correct

Remember: Instagram actively fights automation. This tool will likely break as they update their platform. Use responsibly!
