// inject-scripts.js — Chrome content script (document_start)
// Injects page-context scripts into the Instagram page BEFORE React loads.
// This is critical: react-hook.js must install __REACT_DEVTOOLS_GLOBAL_HOOK__
// before Instagram's React initializes, otherwise we can't capture the fiber tree.

(function () {
  function inject(fileName) {
    var script = document.createElement('script');
    script.src = chrome.runtime.getURL(fileName);
    script.async = false;
    script.onload = function () { this.remove(); };
    document.documentElement.appendChild(script);
  }

  inject('visibility-hack.js');
  inject('react-hook.js');
})();
