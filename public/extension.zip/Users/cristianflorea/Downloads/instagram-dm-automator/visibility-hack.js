// visibility-hack.js — Runs in Instagram page context (injected at document_start)
// Makes Instagram think the tab is always visible and focused,
// so DM automation works even when the tab is minimized or in the background.

(function () {
  'use strict';

  // Override rAF to work when tab is backgrounded (Chrome throttles rAF in hidden tabs)
  window.requestAnimationFrame = function (cb) {
    return setTimeout(function () { cb && cb(); }, 0);
  };
  window.requestIdleCallback = function (cb) { cb && cb(); };

  // Always report document as visible
  Object.defineProperty(document, 'visibilityState', { get: function () { return 'visible'; } });
  Object.defineProperty(document, 'webkitVisibilityState', { get: function () { return 'visible'; } });
  Object.defineProperty(document, 'hidden', { get: function () { return false; } });
  Object.defineProperty(document, 'webkitHidden', { get: function () { return false; } });

  // Override hasFocus to always return true
  Object.defineProperty(document, 'hasFocus', { get: function () { return function () { return true; }; } });
  Document.prototype.hasFocus = new Proxy(Document.prototype.hasFocus, {
    apply: function () { return true; },
  });

  // Block visibility/focus events that Instagram listens for
  function block(e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }

  document.addEventListener('visibilitychange', block, true);
  document.addEventListener('webkitvisibilitychange', block, true);
  window.addEventListener('pagehide', block, true);

  // Block blur/focus events on document and window (not on input elements)
  function blockIfDocOrWin(e) {
    if (e.target === document || e.target === window) block(e);
  }

  document.addEventListener('blur', blockIfDocOrWin, true);
  window.addEventListener('blur', blockIfDocOrWin, true);
  document.addEventListener('focus', blockIfDocOrWin, true);
  window.addEventListener('focus', blockIfDocOrWin, true);
  window.addEventListener('mouseleave', function (e) {
    if (e.target === document || e.target === window) block(e);
  }, true);
})();
