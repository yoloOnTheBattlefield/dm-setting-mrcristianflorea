// popup.js — Single-view command center

// ── DOM refs ──

const headerAccount = document.getElementById('header-account');
const headerDot = document.getElementById('header-dot');
const headerStatus = document.getElementById('header-status');
const headerRestricted = document.getElementById('header-restricted');
const headerGear = document.getElementById('header-gear');

const configOnly = document.getElementById('config-only');
const cfgToken = document.getElementById('cfg-token');
const cfgTestMode = document.getElementById('cfg-test-mode');
const cfgUrl = document.getElementById('cfg-url');
const cfgUrlGroup = document.getElementById('cfg-url-group');
const cfgSave = document.getElementById('cfg-save');

const dashboard = document.getElementById('dashboard');
const sentCountEl = document.getElementById('sent-count');
const totalCountEl = document.getElementById('total-count');

const campaignBar = document.getElementById('campaign-bar');
const campaignIcon = document.getElementById('campaign-icon');
const campaignMsg = document.getElementById('campaign-msg');
const campaignCountdown = document.getElementById('campaign-countdown');
const campaignBadge = document.getElementById('campaign-badge');

const leadCard = document.getElementById('lead-card');

const markRepliedInput = document.getElementById('mark-replied-input');
const markRepliedBtn = document.getElementById('mark-replied-btn');

const followupTabs = document.getElementById('followup-tabs');
const followupList = document.getElementById('followup-list');
const followupPagination = document.getElementById('followup-pagination');
const fuPageInfo = document.getElementById('fu-page-info');
const fuPrevBtn = document.getElementById('fu-prev');
const fuNextBtn = document.getElementById('fu-next');

const pingCard = document.getElementById('ping-card');
const pingLogEl = document.getElementById('ping-log');
const sendPongBtn = document.getElementById('send-pong');

const settingsToggle = document.getElementById('settings-toggle');
const settingsBody = document.getElementById('settings-body');
const setToken = document.getElementById('set-token');
const setTestMode = document.getElementById('set-test-mode');
const setUrl = document.getElementById('set-url');
const setUrlGroup = document.getElementById('set-url-group');
const setSave = document.getElementById('set-save');

// ── State ──

let campaignLoopRunning = false;
let campaignTimeout = null;
let countdownInterval = null;
let currentLead = null;
let currentIgUsername = null;
let followupsPage = 1;
let followupsTotalPages = 1;
let activeTab = 'all';

const FOLLOWUP_STATUS_COLORS = {
  need_reply: 'rgba(245,158,11,0.15);color:#f59e0b',
  waiting_for_them: 'rgba(113,113,122,0.15);color:#71717a',
  follow_up_later: 'rgba(59,130,246,0.15);color:#3b82f6',
  hot_lead: 'rgba(239,68,68,0.15);color:#ef4444',
  link_sent: 'rgba(168,85,247,0.15);color:#a855f7',
  booked: 'rgba(34,197,94,0.15);color:#22c55e',
  not_interested: 'rgba(113,113,122,0.15);color:#71717a',
};

// ── Auto-fill mark-replied with current IG profile ──

chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
  if (tabs[0] && tabs[0].url) {
    var match = tabs[0].url.match(/instagram\.com\/([A-Za-z0-9._]+)\/?/);
    if (match && !['direct', 'explore', 'reels', 'stories', 'p', 'accounts'].includes(match[1])) {
      markRepliedInput.value = match[1].toLowerCase();
      currentIgUsername = match[1].toLowerCase();
    }
  }
});

// ── Init ──

async function init() {
  const config = await chrome.storage.local.get([
    'backendUrl', 'token', 'apiKey', 'igUsername', 'stats', 'pingLog',
    'testMode', 'currentLead', 'outboundAccount', 'dailyLimit', 'activeTask', 'campaignEta'
  ]);

  const hasAuth = config.token || (config.apiKey && config.igUsername);

  if (hasAuth) {
    showDashboard();
    loadStats(config.stats); // show cached stats immediately
    fetchSenderStats(); // then replace with real server data
    renderPingLog(config.pingLog || []);
    updateStatus();

    if (config.outboundAccount) {
      headerAccount.textContent = '@' + config.outboundAccount.username;
    } else if (config.igUsername) {
      headerAccount.textContent = config.igUsername;
    }

    // Populate settings fields
    if (config.token) setToken.value = config.token;
    if (config.backendUrl) setUrl.value = config.backendUrl;
    setTestMode.checked = !!config.testMode;
    updateTestModeUI(!!config.testMode);

    // Restore campaign state
    const activeTask = config.activeTask;
    if (activeTask && Date.now() - activeTask.updatedAt < 120000) {
      renderAutoSending(activeTask.task);
    } else if (config.currentLead) {
      campaignLoopRunning = true;
      renderCampaignLead(config.currentLead);
    } else if (!config.testMode && config.campaignEta && config.campaignEta.nextAt > Date.now()) {
      renderCampaignWaiting(config.campaignEta);
    } else {
      startCampaignLoop();
    }

    // Auto-load follow-ups
    fetchFollowups();
    fetchFollowupStats();
  } else {
    showConfigOnly();
    if (config.backendUrl) cfgUrl.value = config.backendUrl;
    if (config.token) cfgToken.value = config.token;
    cfgTestMode.checked = !!config.testMode;
    updateCfgTestMode(!!config.testMode);
  }
}

function showDashboard() {
  configOnly.classList.remove('active');
  dashboard.style.display = 'flex';
}

function showConfigOnly() {
  configOnly.classList.add('active');
  dashboard.style.display = 'none';
}

// ── Config (initial setup) ──

function updateCfgTestMode(enabled) {
  cfgUrlGroup.style.display = enabled ? '' : 'none';
}

cfgTestMode.addEventListener('change', () => updateCfgTestMode(cfgTestMode.checked));

cfgSave.addEventListener('click', async () => {
  const token = cfgToken.value.trim();
  if (!token) { alert('Please enter your browser token'); return; }

  const backendUrl = cfgUrl.value.trim();
  const testMode = cfgTestMode.checked;

  await chrome.storage.local.set({ backendUrl, token, testMode });
  if (testMode) await chrome.storage.local.remove('campaignEta');

  chrome.runtime.sendMessage({ type: 'CONNECT_SOCKET' });

  // Copy to settings fields
  setToken.value = token;
  setUrl.value = backendUrl;
  setTestMode.checked = testMode;
  updateTestModeUI(testMode);

  showDashboard();
  updateStatus();
  startCampaignLoop();
  fetchFollowups();
  fetchFollowupStats();
});

// ── Settings (collapsible) ──

settingsToggle.addEventListener('click', () => {
  settingsToggle.classList.toggle('open');
  settingsBody.classList.toggle('open');
});

headerGear.addEventListener('click', () => {
  if (!settingsBody.classList.contains('open')) {
    settingsToggle.classList.add('open');
    settingsBody.classList.add('open');
  }
  settingsBody.scrollIntoView({ behavior: 'smooth' });
});

function updateTestModeUI(enabled) {
  setUrlGroup.style.display = enabled ? '' : 'none';
  pingCard.style.display = enabled ? '' : 'none';
}

setTestMode.addEventListener('change', () => {
  const enabled = setTestMode.checked;
  updateTestModeUI(enabled);
  chrome.storage.local.set({ testMode: enabled });
  if (enabled) chrome.storage.local.remove('campaignEta');
});

setSave.addEventListener('click', async () => {
  const token = setToken.value.trim();
  if (!token) { alert('Please enter your browser token'); return; }

  const backendUrl = setUrl.value.trim();
  const testMode = setTestMode.checked;

  await chrome.storage.local.set({ backendUrl, token, testMode });
  if (testMode) await chrome.storage.local.remove('campaignEta');

  chrome.runtime.sendMessage({ type: 'CONNECT_SOCKET' });
  updateTestModeUI(testMode);
  updateStatus();

  setSave.textContent = 'Saved!';
  setTimeout(() => { setSave.textContent = 'Save'; }, 1500);
});

// ── Stats ──

function loadStats(stats) {
  if (!stats) return;
  sentCountEl.textContent = stats.sent || 0;
  totalCountEl.textContent = stats.total || 0;
}

async function fetchSenderStats() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'SENDER_STATS' });
    if (response && response.success && response.data) {
      sentCountEl.textContent = response.data.sent_today || 0;
      totalCountEl.textContent = response.data.total_sent || 0;
    }
  } catch (e) {
    // fall back to local stats
  }
}

// ── Connection UI ──

function updateSocketUI(connected, authenticated) {
  if (connected && authenticated) {
    headerDot.className = 'header-dot connected';
    headerStatus.textContent = 'Live';
    sendPongBtn.disabled = false;
  } else if (connected) {
    headerDot.className = 'header-dot error';
    headerStatus.textContent = 'Auth Failed';
    sendPongBtn.disabled = true;
  } else {
    headerDot.className = 'header-dot';
    headerStatus.textContent = 'Offline';
    sendPongBtn.disabled = true;
  }
}

function showRestricted(until, reason) {
  headerRestricted.classList.add('active');
  headerRestricted.textContent = reason
    ? 'Restricted — ' + reason
    : 'Restricted';
}

function hideRestricted() {
  headerRestricted.classList.remove('active');
}

// ── Campaign Bar ──

function setCampaignBadge(state, text) {
  campaignBadge.className = 'campaign-badge ' + state;
  campaignBadge.textContent = text || state.charAt(0).toUpperCase() + state.slice(1);
}

function setCampaignBar(icon, msg, badge, badgeText) {
  campaignIcon.textContent = icon;
  campaignMsg.textContent = msg;
  campaignCountdown.style.display = 'none';
  setCampaignBadge(badge, badgeText);
  leadCard.style.display = 'none';
}

function renderCampaignIdle(reason) {
  setCampaignBar('', reason || 'No active campaigns', 'idle', 'Idle');
}

function renderCampaignPolling() {
  setCampaignBar('', 'Fetching next lead...', 'polling', 'Polling');
}

function renderCampaignDone() {
  setCampaignBar('', 'All campaigns complete!', 'done', 'Done');
}

function renderCampaignError(error) {
  setCampaignBar('', error, 'idle', 'Error');
  campaignMsg.style.color = 'var(--red)';
}

function renderCampaignWait(waitSeconds) {
  setCampaignBadge('waiting', 'Waiting');
  campaignIcon.textContent = '';
  campaignMsg.textContent = 'Cooling down';
  let remaining = Math.ceil(waitSeconds);
  campaignCountdown.style.display = '';
  campaignCountdown.textContent = formatCountdown(remaining);

  clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    remaining--;
    campaignCountdown.textContent = formatCountdown(Math.max(0, remaining));
    if (remaining <= 0) clearInterval(countdownInterval);
  }, 1000);
}

function renderCampaignWaiting(eta) {
  clearInterval(countdownInterval);

  if (eta && eta.nextAt && eta.nextAt > Date.now()) {
    setCampaignBadge('waiting', 'Waiting');
    let remaining = Math.ceil((eta.nextAt - Date.now()) / 1000);
    const nameText = eta.campaignName || '';
    const pendingText = eta.pendingLeads != null ? eta.pendingLeads + ' left' : '';

    campaignIcon.textContent = '';
    campaignMsg.textContent = nameText ? nameText + (pendingText ? ' · ' + pendingText : '') : (pendingText || 'Next DM in');
    campaignCountdown.style.display = '';
    campaignCountdown.textContent = formatCountdown(remaining);

    countdownInterval = setInterval(() => {
      remaining--;
      campaignCountdown.textContent = formatCountdown(Math.max(0, remaining));
      if (remaining <= 0) {
        clearInterval(countdownInterval);
        renderCampaignWaiting();
      }
    }, 1000);
  } else {
    setCampaignBadge('polling', 'Ready');
    campaignIcon.textContent = '';
    campaignMsg.textContent = 'Waiting for next task...';
    campaignCountdown.style.display = 'none';
  }
  leadCard.style.display = 'none';
}

function renderAutoSending(task) {
  const username = task.target || 'unknown';
  setCampaignBadge('sending', 'Sending');
  campaignIcon.textContent = '';
  campaignMsg.textContent = 'Sending DM to @' + username;
  campaignCountdown.style.display = 'none';
  leadCard.style.display = 'none';
}

function renderAutoSendResult(success, username, error) {
  const msg = success
    ? 'Sent to @' + escapeHtml(username || 'unknown')
    : 'Failed: ' + escapeHtml(error || 'Unknown error');
  setCampaignBadge(success ? 'done' : 'idle', success ? 'Sent' : 'Error');
  campaignMsg.textContent = msg;
  campaignCountdown.style.display = 'none';
}

// ── Active Lead ──

function renderCampaignLead(lead) {
  currentLead = lead;
  chrome.storage.local.set({ currentLead: lead });
  setCampaignBadge('polling', 'Active');
  campaignIcon.textContent = '';
  campaignMsg.textContent = 'Review lead below';
  campaignCountdown.style.display = 'none';

  const username = lead.ig_username || lead.username || 'unknown';
  const fullName = lead.full_name || lead.fullName || '';
  const bio = lead.bio || '';
  const message = lead.message || '';
  const campaignName = lead.campaign_name || lead.campaignName || '';
  const initial = username.charAt(0).toUpperCase();

  leadCard.style.display = '';
  leadCard.innerHTML =
    (campaignName ? '<div class="lead-campaign-name">' + escapeHtml(campaignName) + '</div>' : '') +
    '<div class="lead-user">' +
      '<div class="lead-avatar">' + initial + '</div>' +
      '<div class="lead-details">' +
        '<div class="lead-username"><a href="https://www.instagram.com/' + encodeURIComponent(username) + '/" id="lead-profile-link">@' + escapeHtml(username) + '</a></div>' +
        (fullName ? '<div class="lead-fullname">' + escapeHtml(fullName) + '</div>' : '') +
      '</div>' +
    '</div>' +
    (bio ? '<div class="lead-bio">' + escapeHtml(bio) + '</div>' : '') +
    '<div class="lead-message" id="lead-message-box">' +
      escapeHtml(message) +
      '<span class="copied-toast" id="copied-toast">Copied!</span>' +
    '</div>' +
    '<div class="lead-actions">' +
      '<button class="btn btn-confirm" id="btn-confirm">Confirm Sent</button>' +
      '<button class="btn btn-skip" id="btn-skip">Skip</button>' +
      '<button class="btn btn-cant" id="btn-cant-message">Can\'t Message</button>' +
    '</div>';

  // Copy message on click
  document.getElementById('lead-message-box').addEventListener('click', () => {
    copyMessageAndToast(message);
  });

  // Profile link → navigate current tab + copy message
  document.getElementById('lead-profile-link').addEventListener('click', (e) => {
    e.preventDefault();
    copyToClipboard(message);
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (tabs[0]) chrome.tabs.update(tabs[0].id, { url: e.target.href });
    });
  });

  document.getElementById('btn-confirm').addEventListener('click', () => handleConfirm(lead));
  document.getElementById('btn-skip').addEventListener('click', () => handleSkip(lead));
  document.getElementById('btn-cant-message').addEventListener('click', () => handleSkip(lead, 'cant_message'));
}

// ── Campaign Actions ──

function disableLeadButtons() {
  ['btn-confirm', 'btn-skip', 'btn-cant-message'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = true;
  });
}

async function handleConfirm(lead) {
  disableLeadButtons();
  const campaignLeadId = lead.campaign_lead_id || lead.campaignLeadId || lead._id;

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'CAMPAIGN_CONFIRM',
      data: { campaignLeadId }
    });
    if (!response.success) console.error('Confirm failed:', response.error);

    // Refresh real stats from server
    fetchSenderStats();
  } catch (error) {
    console.error('Confirm error:', error);
  }

  currentLead = null;
  leadCard.style.display = 'none';
  await chrome.storage.local.remove('currentLead');
  campaignPoll();
}

async function handleSkip(lead, reason = 'Skipped by VA') {
  disableLeadButtons();
  const campaignLeadId = lead.campaign_lead_id || lead.campaignLeadId || lead._id;

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'CAMPAIGN_SKIP',
      data: { campaignLeadId, reason }
    });
    if (!response.success) console.error('Skip failed:', response.error);
  } catch (error) {
    console.error('Skip error:', error);
  }

  currentLead = null;
  leadCard.style.display = 'none';
  await chrome.storage.local.remove('currentLead');
  campaignPoll();
}

// ── Campaign Polling Loop ──

function startCampaignLoop() {
  if (campaignLoopRunning) return;
  campaignLoopRunning = true;
  renderCampaignPolling();
  campaignPoll();
}

function stopCampaignLoop() {
  campaignLoopRunning = false;
  currentLead = null;
  chrome.storage.local.remove('currentLead');
  if (campaignTimeout) { clearTimeout(campaignTimeout); campaignTimeout = null; }
  if (countdownInterval) { clearInterval(countdownInterval); countdownInterval = null; }
}

async function campaignPoll() {
  if (!campaignLoopRunning) return;
  if (campaignTimeout) { clearTimeout(campaignTimeout); campaignTimeout = null; }
  if (countdownInterval) { clearInterval(countdownInterval); countdownInterval = null; }

  renderCampaignPolling();

  try {
    const response = await chrome.runtime.sendMessage({ type: 'CAMPAIGN_NEXT' });

    if (!response.success) {
      if (response.error === 'Not authenticated') {
        renderCampaignPolling();
        scheduleNextPoll(3);
        return;
      }
      renderCampaignError(response.error || 'Failed to fetch');
      scheduleNextPoll(30);
      return;
    }

    const data = response.data;
    if (!data || !data.status) {
      renderCampaignIdle('No response from server');
      scheduleNextPoll(30);
      return;
    }

    switch (data.status) {
      case 'idle':
        try {
          const { activeTask } = await chrome.storage.local.get('activeTask');
          if (activeTask && Date.now() - activeTask.updatedAt < 120000) {
            renderAutoSending(activeTask.task);
            campaignLoopRunning = false;
            return;
          }
        } catch (e) {}
        try {
          const status = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
          if (status.authenticated) {
            const { campaignEta } = await chrome.storage.local.get('campaignEta');
            const eta = (campaignEta && campaignEta.nextAt > Date.now()) ? campaignEta : null;
            if (eta) {
              renderCampaignWaiting(eta);
            } else {
              // Show server reason so user knows why no leads are coming
              renderCampaignIdle(data.reason || 'Waiting for next task...');
            }
            campaignLoopRunning = false;
            return;
          }
        } catch (e) {}
        renderCampaignIdle(data.reason || 'No active campaigns');
        scheduleNextPoll(30);
        break;

      case 'wait':
        renderCampaignWait(data.wait_seconds || data.waitSeconds || 30);
        scheduleNextPoll(data.wait_seconds || data.waitSeconds || 30);
        break;

      case 'done':
        renderCampaignDone();
        campaignLoopRunning = false;
        break;

      case 'skipped':
        campaignPoll();
        break;

      case 'lead':
        renderCampaignLead(data.lead || data);
        break;

      default:
        renderCampaignIdle('Unknown status: ' + data.status);
        scheduleNextPoll(30);
        break;
    }
  } catch (error) {
    console.error('Campaign poll error:', error);
    renderCampaignError('Connection error');
    scheduleNextPoll(30);
  }
}

function scheduleNextPoll(seconds) {
  if (!campaignLoopRunning) return;
  campaignTimeout = setTimeout(() => campaignPoll(), seconds * 1000);
}

// ── Ping / Pong ──

function renderPingLog(entries) {
  if (!entries || entries.length === 0) {
    pingLogEl.innerHTML = '<div class="empty">Waiting for pings...</div>';
    return;
  }
  pingLogEl.innerHTML = entries.map(e => {
    const time = new Date(e.receivedAt || e.timestamp).toLocaleTimeString();
    return '<div class="entry">[' + time + '] ' + (e.message || 'ping') + '</div>';
  }).join('');
  pingLogEl.scrollTop = pingLogEl.scrollHeight;
}

sendPongBtn.addEventListener('click', async () => {
  const response = await chrome.runtime.sendMessage({ type: 'SEND_PONG' });
  if (response.success) {
    sendPongBtn.textContent = 'PONG SENT';
    setTimeout(() => { sendPongBtn.textContent = 'SEND PONG'; }, 1500);
  }
});

// ── Mark Replied ──

markRepliedBtn.addEventListener('click', handleMarkReplied);
markRepliedInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') handleMarkReplied();
});

async function handleMarkReplied() {
  var username = markRepliedInput.value.trim().replace(/^@/, '');
  if (!username) return;

  markRepliedBtn.disabled = true;
  markRepliedBtn.textContent = '...';

  try {
    var response = await chrome.runtime.sendMessage({
      type: 'MARK_REPLIED',
      data: { username: username }
    });

    if (response.success) {
      markRepliedInput.value = '';
      markRepliedBtn.textContent = 'Done!';
      setTimeout(() => { markRepliedBtn.textContent = 'Mark Replied'; }, 1500);
      fetchFollowups();
      fetchFollowupStats();
    } else {
      markRepliedBtn.textContent = response.error || 'Error';
      setTimeout(() => { markRepliedBtn.textContent = 'Mark Replied'; }, 2000);
    }
  } catch (err) {
    markRepliedBtn.textContent = 'Error';
    setTimeout(() => { markRepliedBtn.textContent = 'Mark Replied'; }, 2000);
  }

  markRepliedBtn.disabled = false;
}

// ── Follow-Up Tabs ──

followupTabs.addEventListener('click', (e) => {
  const tab = e.target.closest('.followup-tab');
  if (!tab) return;

  followupTabs.querySelectorAll('.followup-tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
  activeTab = tab.getAttribute('data-status');
  followupsPage = 1;
  fetchFollowups();
});

// ── Follow-Up Stats ──

async function fetchFollowupStats() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'FOLLOWUPS_STATS'
    });

    if (response && response.success && response.data) {
      const s = response.data;
      // "All" = only active statuses (exclude booked + not_interested)
      const activeTotal = (s.need_reply || 0) + (s.hot_lead || 0) + (s.follow_up_later || 0) + (s.waiting_for_them || 0) + (s.link_sent || 0);
      setText('count-all', activeTotal);
      setText('count-need_reply', s.need_reply || 0);
      setText('count-hot_lead', s.hot_lead || 0);
      setText('count-follow_up_later', s.follow_up_later || 0);
      setText('count-waiting_for_them', s.waiting_for_them || 0);
      setText('count-link_sent', s.link_sent || 0);
    }
  } catch (e) {
    // silently fail
  }
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ── Follow-Up List ──

fuPrevBtn.addEventListener('click', () => {
  if (followupsPage > 1) { followupsPage--; fetchFollowups(); }
});

fuNextBtn.addEventListener('click', () => {
  if (followupsPage < followupsTotalPages) { followupsPage++; fetchFollowups(); }
});

async function fetchFollowups() {
  followupList.innerHTML = '<div class="fu-loading">Loading...</div>';
  followupPagination.style.display = 'none';

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'FOLLOWUPS_FETCH',
      data: {
        page: followupsPage,
        limit: 20,
        status: activeTab,
        sort: 'priority',
      }
    });

    if (!response.success) {
      followupList.innerHTML = '<div class="fu-empty">' + escapeHtml(response.error || 'Failed to load') + '</div>';
      return;
    }

    const { followUps, pagination } = response.data;
    followupsTotalPages = pagination.totalPages || 1;

    if (!followUps || followUps.length === 0) {
      followupList.innerHTML = '<div class="fu-empty">No follow-ups yet</div>';
      followupPagination.style.display = 'none';
      return;
    }

    // Boost current IG profile to top
    if (currentIgUsername) {
      var matchIdx = followUps.findIndex(function (fu) {
        return fu.lead && fu.lead.username && fu.lead.username.toLowerCase() === currentIgUsername;
      });
      if (matchIdx > 0) {
        var matched = followUps.splice(matchIdx, 1)[0];
        followUps.unshift(matched);
      }
    }

    renderFollowups(followUps);

    if (followupsTotalPages > 1) {
      followupPagination.style.display = '';
      fuPageInfo.textContent = pagination.page + ' / ' + followupsTotalPages;
      fuPrevBtn.disabled = pagination.page <= 1;
      fuNextBtn.disabled = pagination.page >= followupsTotalPages;
    } else {
      followupPagination.style.display = 'none';
    }
  } catch (err) {
    console.error('Follow-ups fetch error:', err);
    followupList.innerHTML = '<div class="fu-empty">' + escapeHtml(err.message || 'Connection error') + '</div>';
  }
}

function renderFollowups(followUps) {
  followupList.innerHTML = followUps.map(function (fu) {
    var username = (fu.lead && fu.lead.username) || 'unknown';
    var fullName = (fu.lead && fu.lead.fullName) || '';
    var initial = username.charAt(0).toUpperCase();
    var statusStyle = FOLLOWUP_STATUS_COLORS[fu.status] || FOLLOWUP_STATUS_COLORS.need_reply;
    var statusLabel = (fu.status || 'need_reply').replace(/_/g, ' ');

    // Build description line
    var descParts = [];
    if (fullName) descParts.push(escapeHtml(fullName));
    if (fu.lead && fu.lead.replied_at) descParts.push('Replied ' + new Date(fu.lead.replied_at).toLocaleDateString());
    if (fu.follow_up_date) descParts.push('Follow-up ' + new Date(fu.follow_up_date).toLocaleDateString());

    var isCurrentProfile = currentIgUsername && username.toLowerCase() === currentIgUsername;

    return '<div class="fu-item' + (isCurrentProfile ? ' fu-current' : '') + '" data-id="' + fu._id + '">' +
      '<div class="fu-top">' +
        '<div class="fu-avatar">' + initial + '</div>' +
        '<div class="fu-info">' +
          '<div class="fu-username"><a href="https://www.instagram.com/' + encodeURIComponent(username) + '/" class="fu-profile-link">@' + escapeHtml(username) + '</a></div>' +
          (descParts.length ? '<div class="fu-desc">' + descParts.join(' · ') + '</div>' : '') +
        '</div>' +
        '<span class="fu-badge" style="background:' + statusStyle + '">' + escapeHtml(statusLabel) + '</span>' +
      '</div>' +
      '<div class="fu-actions">' +
        '<select class="fu-status-select" data-id="' + fu._id + '">' +
          buildStatusOptions(fu.status) +
        '</select>' +
        '<button class="fu-dismiss" data-id="' + fu._id + '" title="Remove">&#10005;</button>' +
      '</div>' +
    '</div>';
  }).join('');

  // Status change listeners
  followupList.querySelectorAll('.fu-status-select').forEach(sel => {
    sel.addEventListener('change', handleFollowupStatusChange);
  });

  // Dismiss listeners
  followupList.querySelectorAll('.fu-dismiss').forEach(btn => {
    btn.addEventListener('click', handleFollowupDismiss);
  });

  // Profile link → navigate in current tab
  followupList.querySelectorAll('.fu-profile-link').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      var url = e.target.href;
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs[0]) chrome.tabs.update(tabs[0].id, { url: url });
      });
    });
  });
}

function buildStatusOptions(current) {
  var statuses = ['need_reply', 'waiting_for_them', 'follow_up_later', 'hot_lead', 'link_sent', 'booked'];
  var labels = {
    need_reply: 'Need Reply',
    waiting_for_them: 'Waiting For Them',
    follow_up_later: 'Follow Up Later',
    hot_lead: 'Hot Lead',
    link_sent: 'Link Sent',
    booked: 'Booked',
  };
  return statuses.map(function (s) {
    return '<option value="' + s + '"' + (s === current ? ' selected' : '') + '>' + (labels[s] || s) + '</option>';
  }).join('');
}

async function handleFollowupStatusChange(e) {
  var select = e.target;
  var id = select.getAttribute('data-id');
  var newStatus = select.value;
  select.disabled = true;

  try {
    var response = await chrome.runtime.sendMessage({
      type: 'FOLLOWUPS_UPDATE',
      data: { id: id, status: newStatus }
    });
    if (!response.success) console.error('Follow-up update failed:', response.error);

    var item = select.closest('.fu-item');
    if (newStatus === 'booked') {
      if (item) item.remove();
      fetchFollowups();
    } else if (item) {
      var badge = item.querySelector('.fu-badge');
      if (badge) {
        var statusStyle = FOLLOWUP_STATUS_COLORS[newStatus] || FOLLOWUP_STATUS_COLORS.need_reply;
        badge.style.cssText = 'background:' + statusStyle;
        badge.textContent = newStatus.replace(/_/g, ' ');
      }
    }

    fetchFollowupStats();
  } catch (err) {
    console.error('Follow-up update error:', err);
  }

  select.disabled = false;
}

async function handleFollowupDismiss(e) {
  var btn = e.target.closest('.fu-dismiss');
  var id = btn.getAttribute('data-id');
  btn.disabled = true;

  try {
    var response = await chrome.runtime.sendMessage({
      type: 'FOLLOWUPS_UPDATE',
      data: { id: id, status: 'not_interested' }
    });

    if (response.success) {
      var item = btn.closest('.fu-item');
      if (item) item.remove();
      fetchFollowups();
      fetchFollowupStats();
    } else {
      console.error('Follow-up dismiss failed:', response.error);
      btn.disabled = false;
    }
  } catch (err) {
    console.error('Follow-up dismiss error:', err);
    btn.disabled = false;
  }
}

// ── Background Messages ──

chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case 'PING_RECEIVED':
      chrome.storage.local.get('pingLog', ({ pingLog = [] }) => {
        renderPingLog(pingLog);
      });
      break;

    case 'SOCKET_STATUS':
      updateSocketUI(message.connected, message.auth);
      if (message.outboundAccount) {
        headerAccount.textContent = '@' + message.outboundAccount.username;
      }
      break;

    case 'SENDER_RESTRICTED':
      showRestricted(message.restrictedUntil, message.reason);
      break;

    case 'SENDER_UNRESTRICTED':
      hideRestricted();
      break;

    case 'TASK_RECEIVED':
      renderAutoSending(message.task);
      break;

    case 'CAMPAIGN_ETA':
      if (!currentLead && !setTestMode?.checked) {
        renderCampaignWaiting({
          nextAt: message.nextAt,
          pendingLeads: message.pendingLeads,
          campaignName: message.campaignName,
        });
      }
      break;

    case 'AUTO_SEND_COMPLETED':
      renderAutoSendResult(true, message.username);
      fetchSenderStats();
      setTimeout(() => {
        chrome.runtime.sendMessage({ type: 'GET_STATUS' }).then(status => {
          if (status.isProcessing && status.currentTask) {
            renderAutoSending(status.currentTask);
          } else if (!campaignLoopRunning) {
            startCampaignLoop();
          }
        }).catch(() => {});
      }, 2000);
      break;

    case 'AUTO_SEND_FAILED':
      renderAutoSendResult(false, null, message.error);
      setTimeout(() => {
        chrome.runtime.sendMessage({ type: 'GET_STATUS' }).then(status => {
          if (status.isProcessing && status.currentTask) {
            renderAutoSending(status.currentTask);
          } else if (!campaignLoopRunning) {
            startCampaignLoop();
          }
        }).catch(() => {});
      }, 3000);
      break;
  }
});

// ── Status Polling ──

async function updateStatus() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
    updateSocketUI(response.socketConnected, response.authenticated);

    if (response.outboundAccount) {
      headerAccount.textContent = '@' + response.outboundAccount.username;
    }

    if (response.isRestricted) {
      showRestricted(response.restrictedUntil);
    } else {
      hideRestricted();
    }

    if (!currentLead) {
      const { activeTask } = await chrome.storage.local.get('activeTask');
      if (activeTask && Date.now() - activeTask.updatedAt < 120000) {
        renderAutoSending(activeTask.task);
      }
    }
  } catch (error) {
    headerDot.className = 'header-dot error';
    headerStatus.textContent = 'Error';
  }
}

setInterval(updateStatus, 5000);

// ── Helpers ──

function copyToClipboard(text) {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed';
  textarea.style.opacity = '0';
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
}

function copyMessageAndToast(message) {
  copyToClipboard(message);
  const toast = document.getElementById('copied-toast');
  if (toast) {
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1200);
  }
}

function formatCountdown(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return m > 0
    ? m + ':' + s.toString().padStart(2, '0')
    : '0:' + s.toString().padStart(2, '0');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ── Boot ──

init();
