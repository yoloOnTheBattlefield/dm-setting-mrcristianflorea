// content.js — Chrome content script injected into Instagram pages
//
// Bridges background.js (chrome messaging) with react-hook.js (page context via postMessage).
// Orchestrates the DM sending flow using React fiber + Lexical editor manipulation.
// Also handles reply checking via IG API (read-only, less detectable).

console.log('[IG-DM] Content script loaded');

// ============================================
// CONFIG
// ============================================

var CONFIG = {
  DOM_CALL_TIMEOUT: 30000,
  REACT_READY_TIMEOUT: 30000,
};

// ============================================
// DOMCONNECTOR — bridge to react-hook.js in page context
// ============================================

var DomConnector = (function () {
  var pending = {};

  window.addEventListener('message', function (event) {
    if (event.source !== window) return;
    if (!event.data || event.data.type !== 'IG_AUTOMATOR_RESPONSE') return;

    var id = event.data.id;
    if (!pending[id]) return;

    if (event.data.success) {
      pending[id].resolve(event.data.result);
    } else {
      pending[id].reject(new Error(event.data.error || 'Unknown error'));
    }
    delete pending[id];
  });

  return {
    call: function (task, data, timeout) {
      timeout = timeout || CONFIG.DOM_CALL_TIMEOUT;

      return new Promise(function (resolve, reject) {
        var id = Date.now() + '_' + Math.random() + '_' + Math.random();

        var timer = setTimeout(function () {
          delete pending[id];
          reject(new Error('domCall("' + task + '") timed out after ' + timeout + 'ms'));
        }, timeout);

        pending[id] = {
          resolve: function (result) { clearTimeout(timer); resolve(result); },
          reject: function (err) { clearTimeout(timer); reject(err); },
        };

        window.postMessage({
          type: 'IG_AUTOMATOR_REQUEST',
          id: id,
          task: task,
          data: data || {},
        }, '*');
      });
    },
  };
})();

function domCall(task, data, timeout) {
  return DomConnector.call(task, data, timeout);
}

// ============================================
// UTILITY
// ============================================

function sleep(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
}

function dmLog(step, detail) {
  console.log('[IG-DM]', step, detail || '');
  try { chrome.runtime.sendMessage({ type: 'DM_LOG', step: step, detail: detail || '' }); } catch (e) {}
}

function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function extractThreadIdFromUrl() {
  // URL format: https://www.instagram.com/direct/t/123456789/
  var match = window.location.pathname.match(/\/direct\/t\/(\d+)/);
  return match ? match[1] : null;
}

// ============================================
// DISMISS "SWITCH ACCOUNTS" DIALOG — hide via CSS
// ============================================

// Hides the "Switch accounts" dialog and its overlay using CSS.
// We can't click Close (redirects to password reset), can't use Escape (React ignores
// synthetic events), and can't remove from DOM (React re-renders it in a loop).
// CSS hiding keeps React happy while making the dialog invisible and non-blocking.
function trySwitchAccountsDismiss() {
  var dialogs = document.querySelectorAll('div[role="dialog"]');
  for (var d = 0; d < dialogs.length; d++) {
    var heading = dialogs[d].querySelector('[role="heading"]');
    if (heading && /switch\s*accounts/i.test(heading.textContent)) {
      // Already hidden?
      if (dialogs[d].dataset.igdmHidden === '1') return false;

      // Hide the overlay wrapper (walk up to the direct child of body)
      var overlay = dialogs[d];
      while (overlay.parentElement && overlay.parentElement !== document.body) {
        overlay = overlay.parentElement;
      }
      overlay.style.cssText = 'display:none !important;';
      dialogs[d].dataset.igdmHidden = '1';
      dmLog('Hidden "Switch accounts" dialog via CSS');
      return true;
    }
  }
  return false;
}

// Auto-dismiss observer — hides the dialog the instant it appears.
// Only runs once per dialog (checks dataset.igdmHidden to avoid repeated work).
var switchAccountsObserver = new MutationObserver(function () {
  trySwitchAccountsDismiss();
});
switchAccountsObserver.observe(document.documentElement, { childList: true, subtree: true });

// Immediate check
trySwitchAccountsDismiss();

// Promise version for the sendDM flow
function dismissSwitchAccountsDialog() {
  trySwitchAccountsDismiss();
  return Promise.resolve();
}

// ============================================
// IG ERROR DETECTION (DOM-based)
// ============================================

var IG_RESTRICTION_PATTERNS = [
  { pattern: /action.?blocked/i, errorType: 'ACTION_BLOCKED' },
  { pattern: /try again later/i, errorType: 'ACTION_BLOCKED' },
  { pattern: /temporarily blocked/i, errorType: 'ACTION_BLOCKED' },
  { pattern: /restrict/i, errorType: 'IG_RESTRICTED' },
  { pattern: /account.+restricted/i, errorType: 'IG_RESTRICTED' },
  { pattern: /rate.?limit/i, errorType: 'RATE_LIMITED' },
  { pattern: /too many/i, errorType: 'RATE_LIMITED' },
  { pattern: /wait.+before/i, errorType: 'RATE_LIMITED' },
  { pattern: /confirm.+(phone|email|identity)/i, errorType: 'CHALLENGE_REQUIRED' },
  { pattern: /verify.+(phone|email|identity)/i, errorType: 'CHALLENGE_REQUIRED' },
  { pattern: /suspicious.?activity/i, errorType: 'CHALLENGE_REQUIRED' },
  { pattern: /challenge_required/i, errorType: 'CHALLENGE_REQUIRED' },
];

function detectIGRestriction() {
  var dialogSelectors = ['div[role="dialog"]', 'div[role="alert"]', 'div[data-testid="dialog"]'];

  for (var s = 0; s < dialogSelectors.length; s++) {
    var elements = document.querySelectorAll(dialogSelectors[s]);
    for (var e = 0; e < elements.length; e++) {
      var text = elements[e].textContent || '';
      for (var p = 0; p < IG_RESTRICTION_PATTERNS.length; p++) {
        if (IG_RESTRICTION_PATTERNS[p].pattern.test(text)) {
          return { errorType: IG_RESTRICTION_PATTERNS[p].errorType, message: text.trim().substring(0, 200) };
        }
      }
    }
  }

  // Check inline error elements
  var errorEls = document.querySelectorAll('span, p, h2, h3');
  for (var i = 0; i < errorEls.length; i++) {
    var elText = errorEls[i].textContent || '';
    for (var j = 0; j < IG_RESTRICTION_PATTERNS.length; j++) {
      if (IG_RESTRICTION_PATTERNS[j].pattern.test(elText)) {
        return { errorType: IG_RESTRICTION_PATTERNS[j].errorType, message: elText.trim().substring(0, 200) };
      }
    }
  }

  return null;
}

// ============================================
// WAIT FOR REACT HOOK TO BE READY
// ============================================

function waitForReactReady() {
  var startTime = Date.now();

  return new Promise(function (resolve, reject) {
    function check() {
      if (Date.now() - startTime > CONFIG.REACT_READY_TIMEOUT) {
        reject(new Error('React hook not ready (fiber tree not captured). Is Instagram fully loaded?'));
        return;
      }

      domCall('ping', {}, 3000)
        .then(function (result) {
          if (result && result.ready) {
            console.log('[IG-DM] React tree ready, fibers:', result.fiberCount);
            resolve();
          } else {
            setTimeout(check, 1000);
          }
        })
        .catch(function () {
          setTimeout(check, 1000);
        });
    }

    check();
  });
}

// ============================================
// NAVIGATE TO /direct/
// ============================================

function ensureOnDirectPage() {
  if (location.pathname.indexOf('/direct/') === 0) {
    return Promise.resolve();
  }

  console.log('[IG-DM] Not on /direct/, navigating via SPA...');

  // Try clicking the Messages nav link (SPA navigation — keeps content script alive)
  var dmLink = document.querySelector('a[href="/direct/inbox/"]');
  if (!dmLink) {
    // Try other selectors for the messages icon
    var svgLabels = ['Messenger', 'Direct messaging', 'Messages', 'Direct'];
    for (var i = 0; i < svgLabels.length; i++) {
      var svg = document.querySelector('svg[aria-label="' + svgLabels[i] + '"]');
      if (svg) {
        dmLink = svg.closest('a');
        if (dmLink) break;
      }
    }
  }

  if (dmLink) {
    dmLink.click();
    // Wait for SPA navigation to complete
    return waitForPath('/direct/', 10000);
  }

  // Fallback: hard navigation (background.js will handle page reload)
  console.log('[IG-DM] SPA navigation failed, doing hard navigation');
  return Promise.reject(Object.assign(
    new Error('Not on /direct/ and could not SPA-navigate. Background will redirect.'),
    { errorType: 'NAVIGATE_REQUIRED' }
  ));
}

function waitForPath(pathPrefix, timeout) {
  var startTime = Date.now();

  return new Promise(function (resolve, reject) {
    function check() {
      if (location.pathname.indexOf(pathPrefix) === 0) {
        // Extra wait for React to render the new route
        setTimeout(resolve, 2000);
        return;
      }
      if (Date.now() - startTime > timeout) {
        reject(new Error('Navigation to ' + pathPrefix + ' timed out'));
        return;
      }
      setTimeout(check, 500);
    }
    check();
  });
}

// ============================================
// SEND DM — React Fiber + Lexical approach
// ============================================

var isExecuting = false;

// Track last DM attempt state so retries can skip completed steps
var lastDMAttempt = { target: null, messageTyped: false };

function sendDM(task) {
  if (isExecuting) {
    return Promise.reject(new Error('Already executing a task'));
  }
  isExecuting = true;

  var target = task.target;
  var message = task.message;

  dmLog('=== sendDM START for @' + target + ' ===');
  dmLog('  URL: ' + location.pathname);
  dmLog('  lastDMAttempt: target=' + lastDMAttempt.target + ', messageTyped=' + lastDMAttempt.messageTyped);
  var personalizedMessage = message.replace(/\{\{username\}\}/g, target);

  // Check if this is a retry for the same target where we already typed the message
  var isResume = (lastDMAttempt.target === target && lastDMAttempt.messageTyped);
  dmLog('  isResume: ' + isResume);

  return waitForReactReady()
    .then(function () {
      dmLog('React ready');
      // Dismiss "Switch accounts" dialog before navigating — it can block nav link clicks
      return dismissSwitchAccountsDialog();
    })
    .then(function () {
      // Fast path: if this is a retry and we already typed the message last attempt,
      // check if it's still in the input and skip straight to sending.
      dmLog('Skip check: isResume=' + isResume + ', onThread=' + (location.pathname.indexOf('/direct/t/') > -1));
      if (isResume && location.pathname.indexOf('/direct/t/') > -1) {
        return domCall('getInputText', {}, 3000)
          .catch(function (e) { dmLog('Skip check: getInputText failed: ' + e.message); return ''; })
          .then(function (currentText) {
            dmLog('Skip check: inputText="' + (currentText || '').substring(0, 50) + '..." len=' + (currentText || '').length);
            if (currentText && currentText.length > 0) {
              dmLog('Resume: message found in input, skipping to send');
              return 'SKIP_TO_SEND';
            }
            dmLog('Resume: input empty despite previous type — running full flow');
          });
      }
    })
    .then(function (skipFlag) {
      if (skipFlag === 'SKIP_TO_SEND') {
        dmLog('Resume: skipping steps 1-6, going straight to send');
        lastDMAttempt = { target: null, messageTyped: false };
        return domCall('sendMessage');
      }
      // Reset state for fresh attempt
      lastDMAttempt = { target: target, messageTyped: false };

      // Normal flow: navigate, search, type, send
      return ensureOnDirectPage()
        .then(function () {
          dmLog('On /direct/ page');
          return sleep(1000);
        })
        .then(function () {
          return domCall('checkNotificationModal').catch(function () {});
        })
        .then(function () {
          return dismissSwitchAccountsDialog();
        })
        .then(function () {
          return domCall('detectError');
        })
        .then(function (hasError) {
          if (hasError) throw Object.assign(new Error('Instagram error page detected'), { errorType: 'IG_RESTRICTED' });
        })
        .then(function () {
          dmLog('Step 1: Clicking New Message button');
          return domCall('clickDialogButton');
        })
        .then(function () {
          return verifyDialogOpened(0);
        })
        .then(function () {
          dmLog('Step 1: Done — dialog visible');
          return sleep(1000);
        })
        .then(function () {
          dmLog('Step 2: Searching for @' + target);
          return domCall('enterUsername', { username: target })
            .then(function () { return sleep(1000); })
            .then(function () { return verifySearchInput(target, 0); });
        })
        .then(function () {
          dmLog('Step 2: Done — search input verified');
          return sleep(2000);
        })
        .then(function () {
          dmLog('Step 3: Waiting for search results');
          return waitForSearchResults(target, 0);
        })
        .then(function () {
          dmLog('Step 3: Done');
          return sleep(1000);
        })
        .then(function () {
          dmLog('Step 4: Opening conversation');
          return domCall('clickChat').catch(function () {
            dmLog('Step 4: Fiber clickChat failed');
          });
        })
        .then(function () {
          return verifyConversationOpened(0);
        })
        .then(function () {
          dmLog('Step 4: Done — conversation opened');
          dmLog('Step 5: Waiting for message input');
          return waitForMessageInput(0);
        })
        .then(function () {
          dmLog('Step 5: Done');
          var threadId = extractThreadIdFromUrl();
          if (threadId) dmLog('Thread ID: ' + threadId);
          return sleep(randomDelay(500, 1000));
        })
        .then(function () {
          return domCall('getInputText', {}, 3000)
            .catch(function () { return ''; })
            .then(function (currentText) {
              if (currentText && currentText.length > 0) {
                dmLog('Step 6: Message already in input, skipping typing');
                return;
              }
              dmLog('Step 6: Typing message (' + personalizedMessage.length + ' chars)');
              return typeMessageViaLexical(personalizedMessage);
            });
        })
        .then(function () {
          dmLog('Step 6: Done');
          lastDMAttempt.messageTyped = true;
          return sleep(randomDelay(300, 600));
        })
        .then(function () {
          dmLog('Step 7: Sending message');
          return domCall('sendMessage');
        });
    })
    .then(function () {
      dmLog('Step 7: Done');
      return sleep(2000);
    })
    .then(function () {
      // Step 8: Verify message was sent
      dmLog('Step 8: Verifying');
      return verifyMessageSent();
    })
    .then(function () {
      // Extract thread ID using multiple strategies (URL, fiber tree, DOM)
      return domCall('getThreadId', {}, 5000)
        .then(function (result) {
          dmLog('Thread ID: ' + (result.threadId || 'not found') + ' (source: ' + result.source + ')');
          return result.threadId;
        })
        .catch(function () {
          // Fallback: URL only
          return extractThreadIdFromUrl();
        });
    })
    .then(function (threadId) {
      dmLog('SUCCESS! DM sent to @' + target + (threadId ? ' (thread: ' + threadId + ')' : ''));
      isExecuting = false;
      lastDMAttempt = { target: null, messageTyped: false };
      return { success: true, username: target, threadId: threadId };
    })
    .catch(function (err) {
      isExecuting = false;
      dmLog('=== sendDM FAILED for @' + target + ' ===');
      dmLog('  error: ' + (err.message || String(err)));
      dmLog('  errorType: ' + (err.errorType || 'none'));
      dmLog('  URL: ' + location.pathname);
      dmLog('  lastDMAttempt: target=' + lastDMAttempt.target + ', messageTyped=' + lastDMAttempt.messageTyped);

      // Try to close any open dialogs to clean up state
      domCall('closeDialog').catch(function () {});

      // Check for IG restrictions on error
      var restriction = detectIGRestriction();
      if (restriction) {
        throw Object.assign(new Error(restriction.message), { errorType: restriction.errorType });
      }

      throw err;
    });
}

// DOM verification: check that the NEW MESSAGE dialog appeared (not just any dialog)
// Must have a search input inside it — prevents false positives from other IG dialogs
function verifyDialogOpened(attempt) {
  if (attempt >= 10) {
    // Dialog didn't open via fiber — try DOM-based click as fallback
    dmLog('Step 1: Dialog not visible, trying DOM fallback');
    var labels = ['New message', 'Nuevo mensaje', 'Nouvelle conversation', 'Neue Nachricht', 'Nova mensagem', 'Nuovo messaggio', 'Nieuw bericht'];
    for (var i = 0; i < labels.length; i++) {
      var btn = document.querySelector('[aria-label="' + labels[i] + '"]');
      if (btn) {
        var clickTarget = btn.closest('[role="button"]') || btn.parentElement || btn;
        clickTarget.click();
        dmLog('Step 1: Clicked DOM button with label "' + labels[i] + '"');
        return sleep(2000).then(function () {
          return verifyDialogOpened(0); // restart verification with stricter check
        });
      }
    }
    throw new Error('New message button not found in DOM');
  }

  // Hide "Switch accounts" dialog if observer hasn't caught it yet
  trySwitchAccountsDismiss();

  // Strict check: dialog must contain a search input (specific to "New message" dialog)
  // Skip hidden dialogs (Switch accounts)
  var dialogs = document.querySelectorAll('div[role="dialog"]');
  for (var d = 0; d < dialogs.length; d++) {
    if (dialogs[d].dataset.igdmHidden === '1') continue;
    var searchInput = dialogs[d].querySelector('input[type="text"], input[name="queryBox"]');
    if (searchInput) return Promise.resolve(true);
  }
  return sleep(500).then(function () { return verifyDialogOpened(attempt + 1); });
}

// DOM verification: check that the search input contains the target username
function verifySearchInput(target, attempt) {
  if (attempt >= 5) {
    // Search input doesn't have the username — type it via DOM
    dmLog('Step 2: Search input empty, trying DOM fallback');
    var dialog = document.querySelector('div[role="dialog"]');
    if (dialog) {
      var input = dialog.querySelector('input[type="text"], input[name="queryBox"], input');
      if (input) {
        var nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(input, target);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        dmLog('Step 2: Typed username via DOM nativeSetter');
        return true;
      }
    }
    // Can't verify but proceed anyway — search might have worked via fiber
    dmLog('Step 2: Could not verify search input, proceeding');
    return true;
  }

  var dialog = document.querySelector('div[role="dialog"]');
  if (dialog) {
    var input = dialog.querySelector('input[type="text"], input[name="queryBox"], input');
    if (input && input.value && input.value.toLowerCase().indexOf(target.toLowerCase()) > -1) {
      return Promise.resolve(true);
    }
  }
  return sleep(500).then(function () { return verifySearchInput(target, attempt + 1); });
}

function waitForSearchResults(target, attempt) {
  if (attempt >= 15) {
    // No results after waiting — close dialog and fail
    return domCall('closeDialog').catch(function () {}).then(function () {
      throw Object.assign(new Error('User @' + target + ' not found in search'), { errorType: 'USER_NOT_FOUND' });
    });
  }

  return domCall('findSearchResult')
    .then(function (results) {
      if (!results || results.length === 0) {
        // Also check DOM for visible search results
        var domResults = document.querySelectorAll('div[role="dialog"] div[role="listbox"] div[role="option"], div[role="dialog"] div[role="button"]');
        if (domResults.length > 0) {
          dmLog('Step 3: Found ' + domResults.length + ' DOM results, checking for @' + target);
          return clickDOMSearchResult(target, domResults);
        }
        return sleep(1000).then(function () { return waitForSearchResults(target, attempt + 1); });
      }

      // ONLY click an exact username match — NEVER click a non-matching result
      var targetLower = target.toLowerCase();
      var exactMatch = null;

      for (var i = 0; i < results.length; i++) {
        var candidate = results[i] && (results[i].candidate || results[i]);
        var username = (candidate && (candidate.secondaryName || candidate.username)) || '';
        dmLog('Step 3: Result[' + i + '] = @' + username);
        if (username.toLowerCase() === targetLower) {
          exactMatch = candidate;
          break;
        }
      }

      if (exactMatch) {
        dmLog('Step 3: Found exact match, clicking @' + target);
        return domCall('clickOnUser', {
          threadId: exactMatch.id,
          userId: exactMatch.igid || exactMatch.pk,
        }).catch(function () {
          // Fiber click failed — try DOM-based click on the matching result
          dmLog('Step 3: Fiber clickOnUser failed, trying DOM click');
          var domResults = document.querySelectorAll('div[role="dialog"] div[role="listbox"] div[role="option"], div[role="dialog"] div[role="button"]');
          return clickDOMSearchResult(target, domResults);
        });
      }

      // No exact match in fiber results — DO NOT click first result (prevents wrong-user DMs)
      // Instead, check DOM for visible search results that might match
      dmLog('Step 3: No exact match in fiber results (' + results.length + ' results), checking DOM');
      var domResults = document.querySelectorAll('div[role="dialog"] div[role="listbox"] div[role="option"], div[role="dialog"] div[role="button"]');
      if (domResults.length > 0) {
        return clickDOMSearchResult(target, domResults);
      }

      // Retry — search results might still be loading
      return sleep(1000).then(function () { return waitForSearchResults(target, attempt + 1); });
    });
}

// Click a search result in the DOM that matches the target username
function clickDOMSearchResult(target, domResults) {
  var targetLower = target.toLowerCase();
  for (var i = 0; i < domResults.length; i++) {
    var el = domResults[i];
    var text = (el.textContent || '').toLowerCase();
    if (text.indexOf(targetLower) > -1) {
      dmLog('Step 3: DOM result[' + i + '] contains @' + target + ', clicking');
      el.click();
      return true;
    }
  }
  // None matched — DO NOT click anything, fail safely
  dmLog('Step 3: No DOM results match @' + target + ' — refusing to click wrong user');
  throw Object.assign(
    new Error('User @' + target + ' not found in search results — refusing to click wrong user'),
    { errorType: 'USER_NOT_FOUND' }
  );
}

// DOM verification: check that the conversation opened (dialog closed after clicking Chat/Next)
function verifyConversationOpened(attempt) {
  if (attempt >= 10) {
    // Dialog still open — try clicking Chat/Next button via DOM
    dmLog('Step 4: Dialog still open, trying DOM Chat/Next click');
    var dialog = document.querySelector('div[role="dialog"]');
    if (dialog) {
      // Try buttons with Chat/Next text
      var chatLabels = ['chat', 'next', 'chatear', 'suivant', 'weiter', 'avanti', 'volgende', 'conversar'];
      var buttons = dialog.querySelectorAll('div[role="button"], button, [tabindex="0"]');
      for (var i = 0; i < buttons.length; i++) {
        var text = (buttons[i].textContent || '').trim().toLowerCase();
        for (var j = 0; j < chatLabels.length; j++) {
          if (text === chatLabels[j]) {
            buttons[i].click();
            dmLog('Step 4: Clicked DOM button "' + text + '"');
            return sleep(2000).then(function () {
              return verifyConversationOpened(0); // restart verification
            });
          }
        }
      }
      // No matching text — click the last button-like element (usually Chat/Next)
      if (buttons.length > 0) {
        var lastBtn = buttons[buttons.length - 1];
        lastBtn.click();
        dmLog('Step 4: Clicked last button in dialog');
        return sleep(2000);
      }
    }
    // Dialog might have closed between checks — proceed anyway
    dmLog('Step 4: Could not verify, proceeding');
    return Promise.resolve();
  }

  // Check if the "New Message" dialog is still open (has search input)
  var dialogs = document.querySelectorAll('div[role="dialog"]');
  for (var d = 0; d < dialogs.length; d++) {
    var searchInput = dialogs[d].querySelector('input[type="text"], input[name="queryBox"]');
    if (searchInput) {
      // Dialog still open — wait and retry
      return sleep(500).then(function () { return verifyConversationOpened(attempt + 1); });
    }
  }
  // Dialog closed — conversation should be open
  return Promise.resolve();
}

function waitForMessageInput(attempt) {
  if (attempt >= 15) {
    return Promise.reject(new Error('Message input not found — conversation may not have opened'));
  }

  // Check via react-hook.js (page context) — it can see __lexicalEditor which is invisible
  // from the content script's isolated world
  return domCall('waitForEditor', {}, 3000)
    .then(function (ready) {
      if (ready) return Promise.resolve();
      return sleep(1000).then(function () { return waitForMessageInput(attempt + 1); });
    })
    .catch(function () {
      return sleep(1000).then(function () { return waitForMessageInput(attempt + 1); });
    });
}

function typeMessageViaLexical(message) {
  // Single domCall that types the entire message in page context — no 302 round-trips.
  // Timeout scales with message length: ~120ms per char + 15s buffer.
  var timeout = Math.max(message.length * 120 + 15000, 30000);
  return domCall('enterFullMessage', { message: message }, timeout);
}

function verifyMessageSent() {
  return domCall('isInputEmpty')
    .then(function (isEmpty) {
      if (!isEmpty) {
        var restriction = detectIGRestriction();
        if (restriction) {
          throw Object.assign(new Error(restriction.message), { errorType: restriction.errorType });
        }
        throw Object.assign(new Error('Message may not have been sent — input still has text'), { errorType: 'UNKNOWN' });
      }
    });
}

// ============================================
// COMMENT ON POST — navigate to profile, click post, focus input
// ============================================

// Wait for the react-hook.js postMessage bridge to be alive (no fiber tree needed)
function waitForBridge(attempt) {
  if (attempt >= 20) {
    return Promise.reject(new Error('React hook bridge not ready — react-hook.js may not be loaded'));
  }
  // Try a lightweight domCall that doesn't need the fiber tree
  return domCall('getPostGrid', {}, 3000)
    .then(function () { return true; })
    .catch(function () {
      return sleep(500).then(function () { return waitForBridge(attempt + 1); });
    });
}

function commentOnPost(task) {
  if (isExecuting) {
    return Promise.reject(new Error('Already executing a task'));
  }
  isExecuting = true;

  var target = task.target;
  var comment = task.message;

  dmLog('[Comment] Starting comment flow for @' + target);

  // Comment flow only needs DOM — skip fiber tree check, just wait for bridge
  return waitForBridge(0)
    .then(function () {
      dmLog('[Comment] Bridge ready');
      // Navigate to the user's profile via SPA
      return navigateToProfile(target);
    })
    .then(function () {
      dmLog('[Comment] On profile page');
      return sleep(randomDelay(2000, 3000));
    })
    .then(function () {
      // Scroll down a bit to look human
      dmLog('[Comment] Scrolling profile');
      var scrollAmount = 200 + Math.floor(Math.random() * 400);
      window.scrollBy({ top: scrollAmount, behavior: 'smooth' });
      return sleep(randomDelay(1000, 2000));
    })
    .then(function () {
      // Get available posts from the grid
      dmLog('[Comment] Getting post grid');
      return domCall('getPostGrid', {}, 10000);
    })
    .then(function (gridResult) {
      if (!gridResult || !gridResult.count || gridResult.count === 0) {
        throw Object.assign(new Error('No posts found on @' + target + ' profile'), { errorType: 'NO_POSTS' });
      }
      dmLog('[Comment] Found ' + gridResult.count + ' posts');

      // Pick a random post from the first 9 (top 3 rows)
      var maxIndex = Math.min(gridResult.count, 9);
      var randomIndex = Math.floor(Math.random() * maxIndex);

      dmLog('[Comment] Clicking post at index ' + randomIndex);
      return domCall('clickPost', { index: randomIndex }, 10000);
    })
    .then(function () {
      // Wait for post modal to open
      dmLog('[Comment] Waiting for post modal');
      return waitForPostModal(0);
    })
    .then(function () {
      dmLog('[Comment] Post modal opened');
      return sleep(randomDelay(1000, 2000));
    })
    .then(function () {
      // Focus the comment input
      dmLog('[Comment] Focusing comment input');
      return domCall('focusCommentInput', {}, 10000);
    })
    .then(function (focusResult) {
      if (!focusResult || !focusResult.found) {
        throw Object.assign(new Error('Comment input not found in post modal'), { errorType: 'INPUT_NOT_FOUND' });
      }
      dmLog('[Comment] Comment input focused (type: ' + focusResult.type + ')');
      return sleep(randomDelay(500, 1000));
    })
    .then(function () {
      // Type the comment
      var personalizedComment = comment.replace(/\{\{username\}\}/g, target);
      dmLog('[Comment] Typing comment (' + personalizedComment.length + ' chars)');
      return domCall('typeComment', { comment: personalizedComment }, 15000);
    })
    .then(function (typeResult) {
      if (!typeResult || !typeResult.typed) {
        throw Object.assign(new Error('Failed to type comment'), { errorType: 'TYPE_FAILED' });
      }
      dmLog('[Comment] Comment typed');
      return sleep(randomDelay(800, 1500));
    })
    .then(function () {
      // Click the "Post" button to submit
      dmLog('[Comment] Clicking Post button');
      return domCall('clickPostButton', {}, 10000);
    })
    .then(function (clickResult) {
      if (!clickResult || !clickResult.clicked) {
        throw Object.assign(new Error('Post button not found in modal'), { errorType: 'SUBMIT_FAILED' });
      }
      dmLog('[Comment] Comment posted!');
      return sleep(randomDelay(1000, 2000));
    })
    .then(function () {
      isExecuting = false;
      dmLog('[Comment] SUCCESS — commented on @' + target);
      return { success: true, username: target, action: 'comment_posted' };
    })
    .catch(function (err) {
      isExecuting = false;
      dmLog('[Comment] FAILED: ' + (err.message || String(err)));
      throw err;
    });
}

function navigateToProfile(username) {
  var targetPath = '/' + username + '/';

  // Already on the profile?
  if (location.pathname === targetPath) {
    return Promise.resolve();
  }

  // Try SPA navigation via clicking a link or using history
  var profileLink = document.querySelector('a[href="' + targetPath + '"]');
  if (profileLink) {
    profileLink.click();
    return waitForPath('/' + username, 10000);
  }

  // Fallback: navigate via location (will reload content scripts, but background.js handles retry)
  window.location.href = 'https://www.instagram.com/' + username + '/';
  return waitForPath('/' + username, 15000);
}

function waitForPostModal(attempt) {
  if (attempt >= 15) {
    return Promise.reject(Object.assign(
      new Error('Post modal did not open'),
      { errorType: 'MODAL_TIMEOUT' }
    ));
  }

  var dialog = document.querySelector('div[role="dialog"]');
  if (dialog) {
    // Verify it's a post modal (has an image or video, not a "New message" dialog)
    var media = dialog.querySelector('img[style], video, img[srcset]');
    if (media) return Promise.resolve();
  }

  return sleep(500).then(function () { return waitForPostModal(attempt + 1); });
}

// ============================================
// REPLY DETECTION — check IG threads via API (read-only, kept as-is)
// ============================================

var IG_API_BASE = 'https://www.instagram.com/api/v1';

var cachedIGState = null;

function extractIGState() {
  if (cachedIGState) return Promise.resolve(cachedIGState);

  return new Promise(function (resolve) {
    var handler = function (event) {
      if (event.data && event.data.type === 'IG_STATE_RESPONSE') {
        window.removeEventListener('message', handler);
        cachedIGState = event.data.state || {};
        resolve(cachedIGState);
      }
    };
    window.addEventListener('message', handler);

    var script = document.createElement('script');
    script.textContent = [
      '(function() {',
      '  var s = {};',
      '  try { s.claim = window.sessionStorage.getItem("www-claim-v2") || "0"; } catch(e) {}',
      '  try {',
      '    var scripts = document.querySelectorAll("script");',
      '    for (var i = 0; i < scripts.length; i++) {',
      '      var m = scripts[i].textContent.match(/"rollout_hash":"([^"]+)"/);',
      '      if (m) { s.ajaxHash = m[1]; break; }',
      '    }',
      '  } catch(e) {}',
      '  window.postMessage({ type: "IG_STATE_RESPONSE", state: s }, "*");',
      '})();',
    ].join('\n');
    document.documentElement.appendChild(script);
    script.remove();

    setTimeout(function () {
      window.removeEventListener('message', handler);
      if (!cachedIGState) {
        cachedIGState = {};
        resolve(cachedIGState);
      }
    }, 2000);
  });
}

function buildIGHeaders(csrfToken, igState) {
  var h = {
    'X-CSRFToken': csrfToken,
    'X-IG-App-ID': '936619743392459',
    'X-Requested-With': 'XMLHttpRequest',
  };
  if (igState.claim) h['X-IG-WWW-Claim'] = igState.claim;
  if (igState.ajaxHash) h['X-Instagram-AJAX'] = igState.ajaxHash;
  return h;
}

function checkReplies(threads) {
  console.log('[Reply] Checking ' + threads.length + ' thread(s) for replies');

  var csrfCookie = document.cookie.split('; ').find(function (c) { return c.indexOf('csrftoken=') === 0; });
  var csrfToken = csrfCookie ? csrfCookie.split('=')[1] : null;

  if (!csrfToken) {
    return Promise.reject(Object.assign(new Error('No CSRF token'), { errorType: 'SESSION_EXPIRED' }));
  }

  return extractIGState().then(function (igState) {
    var headers = buildIGHeaders(csrfToken, igState);
    var results = [];
    var index = 0;

    function checkNext() {
      if (index >= threads.length) return Promise.resolve(results);

      var t = threads[index];
      index++;

      var delayPromise = results.length > 0 ? sleep(1000 + Math.random() * 1000) : Promise.resolve();

      return delayPromise
        .then(function () {
          return fetch(IG_API_BASE + '/direct_v2/threads/' + t.thread_id + '/', {
            method: 'GET',
            headers: headers,
            credentials: 'same-origin',
          });
        })
        .then(function (resp) {
          if (resp.status === 429) {
            console.warn('[Reply] Rate limited, stopping batch');
            return results;
          }

          if (!resp.ok) {
            console.warn('[Reply] Thread ' + t.thread_id + ' fetch failed (' + resp.status + ')');
            results.push({ lead_id: t.lead_id, thread_id: t.thread_id, has_reply: false, error: 'HTTP ' + resp.status });
            return checkNext();
          }

          return resp.json().then(function (data) {
            var thread = data.thread;
            if (!thread || !thread.items) {
              results.push({ lead_id: t.lead_id, thread_id: t.thread_id, has_reply: false });
              return checkNext();
            }

            var viewerId = thread.viewer_id ? thread.viewer_id.toString() : null;
            var hasReply = false;
            var repliedAt = null;

            for (var i = 0; i < thread.items.length; i++) {
              var senderId = thread.items[i].user_id ? thread.items[i].user_id.toString() : null;
              if (senderId && senderId !== viewerId) {
                hasReply = true;
                repliedAt = thread.items[i].timestamp ? new Date(thread.items[i].timestamp / 1000) : new Date();
                break;
              }
            }

            console.log('[Reply] @' + t.username + ' thread ' + t.thread_id + ': reply=' + hasReply);
            results.push({
              lead_id: t.lead_id,
              thread_id: t.thread_id,
              has_reply: hasReply,
              replied_at: repliedAt ? repliedAt.toISOString() : null,
            });
            return checkNext();
          });
        })
        .catch(function (err) {
          console.error('[Reply] Error checking thread ' + t.thread_id + ':', err.message);
          results.push({ lead_id: t.lead_id, thread_id: t.thread_id, has_reply: false, error: err.message });
          return checkNext();
        });
    }

    return checkNext();
  });
}

// ============================================
// MESSAGE LISTENERS
// ============================================

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  console.log('[IG-DM] Content script received:', message.type);

  switch (message.type) {
    case 'SEND_DM':
    case 'SEND_DM_API': // backward compat — both route to Lexical-based flow
      sendDM(message.task)
        .then(function (result) {
          sendResponse({ success: true, result: result });
        })
        .catch(function (err) {
          sendResponse({
            success: false,
            error: err.message,
            errorType: err.errorType || 'UNKNOWN',
          });
        });
      return true; // keep channel open for async response

    case 'COMMENT_POST':
      commentOnPost(message.task)
        .then(function (result) {
          sendResponse({ success: true, result: result });
        })
        .catch(function (err) {
          sendResponse({
            success: false,
            error: err.message,
            errorType: err.errorType || 'UNKNOWN',
          });
        });
      return true;

    case 'CHECK_REPLIES':
      checkReplies(message.threads)
        .then(function (results) { sendResponse({ success: true, results: results }); })
        .catch(function (err) { sendResponse({ success: false, error: err.message }); });
      return true;

    case 'PING_CONTENT':
      // Check multiple signals for logged-in state (csrftoken may be HttpOnly now)
      var hasCsrf = document.cookie.indexOf('csrftoken=') > -1;
      var hasSessionId = document.cookie.indexOf('sessionid=') > -1;
      var hasDS = document.cookie.indexOf('ds_user_id=') > -1;
      // DOM fallback: logged-in IG always has navigation or inbox elements
      var hasLoggedInDOM = !!document.querySelector('a[href="/direct/inbox/"]')
        || !!document.querySelector('svg[aria-label="Home"]')
        || !!document.querySelector('svg[aria-label="Messenger"]')
        || window.location.pathname.startsWith('/direct/');
      sendResponse({
        alive: true,
        url: window.location.href,
        hasSession: hasCsrf || hasSessionId || hasDS || hasLoggedInDOM,
      });
      return;
  }
});

// ============================================
// INIT
// ============================================

if (window.location.hostname.indexOf('instagram.com') > -1) {
  console.log('[IG-DM] Instagram page detected — React fiber + Lexical DM ready');
}
