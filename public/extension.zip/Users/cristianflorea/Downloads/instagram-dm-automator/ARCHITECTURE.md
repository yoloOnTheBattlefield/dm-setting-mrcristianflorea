# Architecture & Flow Diagram

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Chrome Browser                           │
│                                                              │
│  ┌────────────────┐         ┌──────────────────┐           │
│  │  Popup UI      │◄────────┤  Background      │           │
│  │  (popup.html)  │         │  Service Worker  │           │
│  │                │         │  (background.js) │           │
│  └────────┬───────┘         └────────┬─────────┘           │
│           │                          │                      │
│           │ Display Status           │ Manage Tasks         │
│           │                          │                      │
│           │                          │                      │
│  ┌────────▼──────────────────────────▼─────────┐           │
│  │         Content Script                      │           │
│  │         (content.js)                        │           │
│  │  ┌──────────────────────────────────────┐  │           │
│  │  │  InstagramAutomator Class            │  │           │
│  │  │  • sendDirectMessage()               │  │           │
│  │  │  • navigateToProfile()               │  │           │
│  │  │  • findMessageButton()               │  │           │
│  │  │  • typeMessage()                     │  │           │
│  │  │  • findSendButton()                  │  │           │
│  │  └──────────────────────────────────────┘  │           │
│  └──────────────────────┬──────────────────────┘           │
│                         │                                   │
│                         │ DOM Manipulation                  │
│                         │                                   │
│  ┌──────────────────────▼──────────────────────┐           │
│  │         Instagram.com                       │           │
│  │  • Profile pages                            │           │
│  │  • Direct message interface                 │           │
│  │  • Message input boxes                      │           │
│  └─────────────────────────────────────────────┘           │
│                                                              │
└──────────────────┬───────────────────────────────────────────┘
                   │
                   │ HTTPS API Calls
                   │ (Tasks, Logs, Status)
                   │
┌──────────────────▼───────────────────────────────────────────┐
│                   Backend Server                              │
│                   (Node.js/Express)                           │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  API Endpoints                                      │    │
│  │  • GET  /api/tasks/next                            │    │
│  │  • POST /api/tasks/:id/complete                    │    │
│  │  • POST /api/tasks/:id/failed                      │    │
│  │  • POST /api/tasks                                 │    │
│  │  • POST /api/logs                                  │    │
│  │  • GET  /api/logs                                  │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  Authentication Middleware                          │    │
│  │  • API Key validation                              │    │
│  │  • User identification                             │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
└──────────────────┬────────────────────────────────────────────┘
                   │
                   │ Read/Write
                   │
┌──────────────────▼────────────────────────────────────────────┐
│                   Database                                     │
│                   (PostgreSQL/MongoDB)                         │
│                                                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │   Tasks      │  │    Logs      │  │    Users     │       │
│  │  • id        │  │  • event     │  │  • id        │       │
│  │  • userId    │  │  • taskId    │  │  • apiKey    │       │
│  │  • type      │  │  • timestamp │  │  • stats     │       │
│  │  • target    │  │  • data      │  │  • limits    │       │
│  │  • message   │  └──────────────┘  └──────────────┘       │
│  │  • status    │                                             │
│  └──────────────┘                                             │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

## Message Flow

### 1. Task Creation Flow

```
User/System
    │
    │ 1. Create Task
    ├──────────────────────►  Backend API
    │                         POST /api/tasks
    │                             │
    │                             │ 2. Store Task
    │                             ▼
    │                         Database
    │                         (status: pending)
    │
    │ 3. Response
    ◄──────────────────────┤
   Task Created
```

### 2. Task Execution Flow

```
Extension              Background           Content Script        Instagram
    │                      │                       │                  │
    │  Timer/Manual        │                       │                  │
    │  Check Tasks         │                       │                  │
    ├─────────────────────►│                       │                  │
    │                      │                       │                  │
    │                      │ GET /api/tasks/next   │                  │
    │                      ├──────────────────►    │                  │
    │                      │                       │                  │
    │                      │◄──────────────────    │                  │
    │                      │ Task Object           │                  │
    │                      │                       │                  │
    │                      │ Execute Task          │                  │
    │                      ├──────────────────────►│                  │
    │                      │                       │                  │
    │                      │                       │ Navigate to      │
    │                      │                       │ Profile          │
    │                      │                       ├─────────────────►│
    │                      │                       │                  │
    │                      │                       │                  │
    │                      │                       │ Find Message Btn │
    │                      │                       ├─────────────────►│
    │                      │                       │                  │
    │                      │                       │ Click            │
    │                      │                       ├─────────────────►│
    │                      │                       │                  │
    │                      │                       │ Type Message     │
    │                      │                       ├─────────────────►│
    │                      │                       │                  │
    │                      │                       │ Click Send       │
    │                      │                       ├─────────────────►│
    │                      │                       │                  │
    │                      │                       │◄─────────────────┤
    │                      │                       │ Success!         │
    │                      │                       │                  │
    │                      │ POST /tasks/complete  │                  │
    │                      │◄──────────────────────┤                  │
    │                      │                       │                  │
    │                      │ Update Database       │                  │
    │                      ├──────────────────►    │                  │
    │                      │                       │                  │
    │  Update UI           │                       │                  │
    │◄─────────────────────┤                       │                  │
    │                      │                       │                  │
```

### 3. Error Handling Flow

```
Content Script         Background              Backend
      │                    │                      │
      │ Execution Error    │                      │
      │                    │                      │
      │ POST /tasks/failed │                      │
      ├───────────────────►│                      │
      │                    │                      │
      │                    │ Update Task Status   │
      │                    ├─────────────────────►│
      │                    │                      │
      │                    │ Store Error Details  │
      │                    │◄─────────────────────┤
      │                    │                      │
      │ Log Event          │                      │
      ├───────────────────►│                      │
      │                    │                      │
      │                    │ POST /api/logs       │
      │                    ├─────────────────────►│
      │                    │                      │
```

## Data Models

### Task Object
```javascript
{
  id: "task_1234567890_abc123",
  userId: "user1",
  type: "send_dm",
  target: "instagram_username",
  message: "Hi {{username}}, check this out!",
  status: "pending" | "in_progress" | "completed" | "failed",
  createdAt: "2024-02-10T12:00:00.000Z",
  startedAt: "2024-02-10T12:01:00.000Z",
  completedAt: "2024-02-10T12:01:30.000Z",
  result: {
    success: true,
    username: "instagram_username"
  },
  error: null
}
```

### Log Object
```javascript
{
  userId: "user1",
  event: "task_started" | "task_completed" | "task_failed",
  taskId: "task_1234567890_abc123",
  data: {
    target: "username",
    error: "Error message if failed"
  },
  timestamp: 1707566400000,
  receivedAt: "2024-02-10T12:00:00.000Z"
}
```

## Security Layers

```
┌─────────────────────────────────────────┐
│  1. Chrome Extension                    │
│     • Content Security Policy           │
│     • Limited Permissions               │
│     • Sandboxed Execution               │
└──────────────┬──────────────────────────┘
               │
               │ HTTPS Only
               │
┌──────────────▼──────────────────────────┐
│  2. Backend API                         │
│     • API Key Authentication            │
│     • Request Validation                │
│     • Rate Limiting                     │
│     • Input Sanitization                │
└──────────────┬──────────────────────────┘
               │
               │ Encrypted Connection
               │
┌──────────────▼──────────────────────────┐
│  3. Database                            │
│     • Encrypted at Rest                 │
│     • Access Control                    │
│     • Audit Logging                     │
│     • Regular Backups                   │
└─────────────────────────────────────────┘
```

## Rate Limiting Strategy

```
User Request
    │
    ▼
┌───────────────────┐
│ API Gateway       │
│ • Check global    │◄─── Redis
│   rate limit      │      (request counters)
└────────┬──────────┘
         │ ✓ Within Limit
         │
         ▼
┌───────────────────┐
│ Task Queue        │
│ • Max tasks/hour  │◄─── Database
│ • Priority system │      (task counts)
└────────┬──────────┘
         │ ✓ Can Add Task
         │
         ▼
┌───────────────────┐
│ Execution Layer   │
│ • Delay between   │◄─── Config
│   messages        │      (timing rules)
│ • Instagram       │
│   compliance      │
└───────────────────┘
```

## Scaling Considerations

### Small Scale (MVP)
- Single server
- In-memory storage
- Direct API calls
- **Handles:** ~10 users, ~100 tasks/day

### Medium Scale
- Load balanced servers
- PostgreSQL database
- Redis for caching
- Background job queue
- **Handles:** ~1,000 users, ~10,000 tasks/day

### Large Scale
- Kubernetes cluster
- Distributed database
- Message queue (RabbitMQ)
- Microservices architecture
- CDN for static assets
- **Handles:** ~100,000 users, ~1M tasks/day

## Monitoring Points

```
Extension
  ├─ Performance metrics
  ├─ Error rates
  └─ User actions

Backend
  ├─ API response times
  ├─ Task success/failure rates
  ├─ Queue length
  └─ Database performance

Instagram
  ├─ Rate limit hits
  ├─ Account blocks
  └─ DOM change detection
```
