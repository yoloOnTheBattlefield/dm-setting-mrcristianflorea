# Creating Extension Icons

The extension needs 3 icon sizes in the `icons/` folder:
- icon16.png (16x16px)
- icon48.png (48x48px)
- icon128.png (128x128px)

## Quick Method: Online Generator

1. **Use Favicon Generator:**
   - Go to https://favicon.io/favicon-generator/
   - Text: "DM" or "📨"
   - Background: Circular, #667eea (purple)
   - Font: Roboto
   - Download all sizes

2. **Rename files:**
   ```
   favicon-16x16.png → icon16.png
   favicon-48x48.png → icon48.png
   favicon-128x128.png → icon128.png
   ```

3. **Move to icons folder:**
   ```bash
   mv *.png icons/
   ```

## Method 2: Use Emoji to PNG

1. Go to https://emojipng.com/
2. Search "envelope" or "message"
3. Download in different sizes
4. Rename and move to `icons/`

## Method 3: Canva

1. Go to https://canva.com
2. Create new design (Custom dimensions)
3. Make three designs:
   - 16x16px
   - 48x48px  
   - 128x128px
4. Add elements:
   - Background circle (purple #667eea)
   - Text "DM" or message icon
5. Download as PNG
6. Save to `icons/` folder

## Method 4: Figma

1. Open Figma
2. Create frame (16x16, 48x48, 128x128)
3. Design your icon
4. Export as PNG
5. Save to `icons/`

## Method 5: Command Line (ImageMagick)

If you have ImageMagick installed:

```bash
cd icons/

# Create a simple purple circle with DM text
convert -size 128x128 xc:none -fill "#667eea" -draw "circle 64,64 64,4" \
  -fill white -pointsize 60 -gravity center -annotate +0+0 "DM" \
  icon128.png

convert icon128.png -resize 48x48 icon48.png
convert icon128.png -resize 16x16 icon16.png
```

## Method 6: Use Placeholder

For testing, you can use solid color squares:

```bash
cd icons/

# Create solid purple squares (quick and dirty)
convert -size 128x128 xc:"#667eea" icon128.png
convert -size 48x48 xc:"#667eea" icon48.png
convert -size 16x16 xc:"#667eea" icon16.png
```

## Recommended Design

**Simple and Clean:**
- Background: Purple gradient (#667eea to #764ba2)
- Icon: White envelope or message bubble
- Style: Flat, modern
- Padding: 10-15% from edges

**Example SVG you can convert:**

```svg
<svg width="128" height="128" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>
  
  <rect width="128" height="128" rx="20" fill="url(#grad)"/>
  
  <!-- Message icon -->
  <rect x="24" y="44" width="80" height="50" rx="8" fill="none" 
        stroke="white" stroke-width="6"/>
  <path d="M 24 44 L 64 74 L 104 44" fill="none" 
        stroke="white" stroke-width="6" stroke-linejoin="round"/>
</svg>
```

Save this as `icon.svg` and convert to PNG using:
- https://convertio.co/svg-png/
- Or any SVG to PNG converter

## Don't Have Design Skills?

**Use these free resources:**

1. **Free Icon Packs:**
   - https://www.flaticon.com (search "message")
   - https://icons8.com (search "dm")
   - https://www.iconfinder.com

2. **AI Generation:**
   - https://www.brandmark.io/tools/logo-crunch (resize logos)
   - Upload any image and resize to needed dimensions

3. **Stock Photos:**
   - https://unsplash.com (search "message icon")
   - Crop and resize

## Current Status

**IMPORTANT:** The icons folder is currently empty. You MUST add icons before the extension will work properly.

Without icons, you'll see:
- ❌ Warning in chrome://extensions/
- ❌ Broken icon in toolbar
- ✅ Extension will still function

## Testing Icons

After adding icons:

1. Go to `chrome://extensions/`
2. Click "Reload" on your extension
3. Check toolbar - icon should appear
4. Click icon - popup should show with icon in title

## Tips

- **Keep it simple** - Icons are tiny, complex designs don't work
- **High contrast** - Make sure it's visible on both light/dark toolbars
- **Brand consistency** - Use same colors as your popup UI
- **Test visibility** - Check icon on both light and dark browser themes
- **Square aspect ratio** - Keep designs centered, some browsers crop

---

For MVP testing, even colored squares work fine. Focus on functionality first, polish icons later! 🎨
