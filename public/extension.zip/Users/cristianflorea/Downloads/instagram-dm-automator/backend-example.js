// backend-example.js - Simple Node.js/Express backend for Instagram DM automation
// Run with: node backend-example.js

const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:*", "chrome-extension://*"],
    methods: ["GET", "POST"],
  },
});

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage (replace with database in production)
const tasks = [];
const completedTasks = [];
const failedTasks = [];
const logs = [];

// Simple API key authentication middleware
const API_KEYS = {
  "your-secret-key-123": { userId: "user1", name: "Demo User" },
};

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization" });
  }

  const apiKey = authHeader.substring(7);
  const user = API_KEYS[apiKey];

  if (!user) {
    return res.status(401).json({ error: "Invalid API key" });
  }

  req.user = user;
  next();
}

// ============================================
// SOCKET.IO
// ============================================

io.on("connection", (socket) => {
  console.log(`Socket connected: ${socket.id}`);

  socket.on("auth:apikey", (apiKey) => {
    const user = API_KEYS[apiKey];
    if (!user) {
      socket.emit("auth:error", { message: "Invalid API key" });
      return;
    }

    // Store user on socket and join their room
    socket.user = user;
    socket.join(`account:${user.userId}`);
    socket.emit("auth:ok", { userId: user.userId, name: user.name });
    console.log(`Socket ${socket.id} authenticated as ${user.name} (${user.userId})`);
  });

  socket.on("ext:pong", (data) => {
    if (!socket.user) return;
    console.log(`Pong from extension (${socket.user.name}):`, data);
    // Re-broadcast to the account room (dashboard will receive it)
    socket.to(`account:${socket.user.userId}`).emit("ext:pong", {
      ...data,
      from: "extension",
      receivedAt: Date.now(),
    });
  });

  socket.on("disconnect", () => {
    console.log(`Socket disconnected: ${socket.id}`);
  });
});

// ============================================
// API ENDPOINTS
// ============================================

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
  });
});

// Ping the extension (called from dashboard/curl)
app.post("/api/tasks/ping", authenticate, (req, res) => {
  const userId = req.user.userId;
  const payload = {
    message: req.body.message || "ping from dashboard",
    timestamp: Date.now(),
  };

  io.to(`account:${userId}`).emit("ext:ping", payload);
  console.log(`Ping sent to account:${userId}`, payload);

  res.json({ success: true, payload });
});

// Get next task
app.get("/api/tasks/next", authenticate, (req, res) => {
  const userId = req.user.userId;

  // Find next pending task for this user
  const task = tasks.find((t) => t.userId === userId && t.status === "pending");

  if (task) {
    // Mark as in-progress
    task.status = "in_progress";
    task.startedAt = new Date().toISOString();

    console.log(`Assigned task ${task.id} to extension`);
  }

  res.json(task || null);
});

// Mark task as completed
app.post("/api/tasks/:taskId/complete", authenticate, (req, res) => {
  const { taskId } = req.params;
  const { result } = req.body;

  const taskIndex = tasks.findIndex((t) => t.id === taskId);

  if (taskIndex === -1) {
    return res.status(404).json({ error: "Task not found" });
  }

  const task = tasks[taskIndex];
  task.status = "completed";
  task.completedAt = new Date().toISOString();
  task.result = result;

  // Move to completed tasks
  completedTasks.push(task);
  tasks.splice(taskIndex, 1);

  console.log(`Task ${taskId} completed successfully`);

  res.json({ success: true });
});

// Mark task as failed
app.post("/api/tasks/:taskId/failed", authenticate, (req, res) => {
  const { taskId } = req.params;
  const { error } = req.body;

  const taskIndex = tasks.findIndex((t) => t.id === taskId);

  if (taskIndex === -1) {
    return res.status(404).json({ error: "Task not found" });
  }

  const task = tasks[taskIndex];
  task.status = "failed";
  task.failedAt = new Date().toISOString();
  task.error = error;

  // Move to failed tasks
  failedTasks.push(task);
  tasks.splice(taskIndex, 1);

  console.log(`Task ${taskId} failed:`, error);

  res.json({ success: true });
});

// Create new task (for testing)
app.post("/api/tasks", authenticate, (req, res) => {
  const { type, target, message } = req.body;

  const task = {
    id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    userId: req.user.userId,
    type,
    target,
    message,
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  tasks.push(task);

  console.log(`Created new task ${task.id} for ${target}`);

  res.json(task);
});

// Get all tasks
app.get("/api/tasks", authenticate, (req, res) => {
  const userId = req.user.userId;

  res.json({
    pending: tasks.filter((t) => t.userId === userId),
    completed: completedTasks.filter((t) => t.userId === userId),
    failed: failedTasks.filter((t) => t.userId === userId),
  });
});

// Log endpoint
app.post("/api/logs", authenticate, (req, res) => {
  const log = {
    userId: req.user.userId,
    ...req.body,
    receivedAt: new Date().toISOString(),
  };

  logs.push(log);
  console.log("Log received:", log);

  res.json({ success: true });
});

// Get logs
app.get("/api/logs", authenticate, (req, res) => {
  const userId = req.user.userId;
  const userLogs = logs.filter((l) => l.userId === userId);

  res.json(userLogs.slice(-100)); // Last 100 logs
});

// ============================================
// START SERVER
// ============================================

const PORT = process.env.PORT || 3500;

server.listen(PORT, () => {
  console.log(`\n Instagram DM Automation Backend`);
  console.log(` Server running on http://localhost:${PORT}`);
  console.log(` Socket.IO ready on same port`);
  console.log(` API Key: your-secret-key-123`);
  console.log(`\n API Endpoints:`);
  console.log(`   GET  /api/health`);
  console.log(`   POST /api/tasks/ping        (sends ext:ping via socket)`);
  console.log(`   GET  /api/tasks/next`);
  console.log(`   POST /api/tasks`);
  console.log(`   GET  /api/tasks`);
  console.log(`   POST /api/tasks/:taskId/complete`);
  console.log(`   POST /api/tasks/:taskId/failed`);
  console.log(`   POST /api/logs`);
  console.log(`   GET  /api/logs`);
  console.log(`\n Test ping/pong:`);
  console.log(`   curl -X POST http://localhost:${PORT}/api/tasks/ping \\`);
  console.log(`     -H "Authorization: Bearer your-secret-key-123" \\`);
  console.log(`     -H "Content-Type: application/json" \\`);
  console.log(`     -d '{"message": "hello extension!"}'\n`);
});
