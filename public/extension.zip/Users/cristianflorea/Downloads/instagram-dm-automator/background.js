// background.js - Service Worker for handling backend communication via Socket.IO

importScripts('socket.io.min.js');

const PRODUCTION_BACKEND_URL = 'https://quddify-server-production.up.railway.app';

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

async function getBackendUrl() {
  const { backendUrl, testMode } = await chrome.storage.local.get(['backendUrl', 'testMode']);
  // Only use custom URL if test mode is enabled and a URL was provided
  if (testMode && backendUrl) {
    // Strip trailing /api, /api/, or trailing slash so we always get the base origin
    return backendUrl.replace(/\/api\/?$/, '').replace(/\/$/, '');
  }
  return PRODUCTION_BACKEND_URL;
}

// Generate or retrieve a persistent browser ID
async function getOrCreateBrowserId() {
  const { browserId } = await chrome.storage.local.get('browserId');
  if (browserId) return browserId;
  const id = 'br_' + crypto.randomUUID();
  await chrome.storage.local.set({ browserId: id });
  return id;
}

// Socket.IO connection
let socket = null;
let isAuthenticated = false;
let senderId = null;
let outboundAccount = null;
let dailyLimit = null;
let heartbeatInterval = null;

// State management
let currentTask = null;
let isProcessing = false;
let waitTimer = null;

// ============================================
// SOCKET CONNECTION + AUTH
// ============================================

async function connectSocket() {
  const { token, apiKey, igUsername } = await chrome.storage.local.get(['token', 'apiKey', 'igUsername']);

  // Token-based auth (new flow)
  if (token) {
    return connectWithToken(token);
  }

  // Legacy API key auth (backward compat)
  if (apiKey && igUsername) {
    return connectWithApiKey(apiKey, igUsername);
  }

  console.log('No token or apiKey configured, skipping socket connection');
}

async function connectWithToken(token) {
  if (socket && socket.connected) {
    console.log('Socket already connected');
    return;
  }

  const browserId = await getOrCreateBrowserId();
  const baseUrl = await getBackendUrl();
  console.log('[DEBUG] Connecting to:', baseUrl);

  // Test HTTP connectivity first
  try {
    const testRes = await fetch(`${baseUrl}/api/debug`);
    const testData = await testRes.json();
    console.log('[DEBUG] HTTP test OK:', testData);
  } catch (err) {
    console.error('[DEBUG] HTTP test FAILED:', err.message);
  }

  socket = io(baseUrl, {
    transports: ['websocket'],
  });

  socket.on('connect', () => {
    console.log('[DEBUG] Socket connected:', socket.id);
    socket.emit('auth:apikey', { token, browser_id: browserId });
  });

  socket.on('connect_error', (err) => {
    console.error('[DEBUG] Socket connect_error:', err.message, err.type, err.description);
  });

  socket.on('auth:ok', (data) => {
    isAuthenticated = true;
    senderId = data.sender_id;
    outboundAccount = data.outbound_account || null;
    dailyLimit = data.daily_limit ?? null;
    console.log('Authenticated! account_id:', data.account_id, 'sender_id:', data.sender_id, 'outbound:', outboundAccount?.username);
    chrome.storage.local.set({
      senderId: data.sender_id,
      outboundAccount: outboundAccount,
      dailyLimit: dailyLimit,
    });
    startHeartbeat();
    startReplyChecking();
    chrome.runtime.sendMessage({
      type: 'SOCKET_STATUS',
      connected: true,
      auth: true,
      outboundAccount,
      dailyLimit,
    }).catch(() => {});
  });

  socket.on('auth:error', ({ error }) => {
    isAuthenticated = false;
    senderId = null;
    outboundAccount = null;
    console.error('Auth failed:', error);
    chrome.runtime.sendMessage({ type: 'SOCKET_STATUS', connected: true, auth: false, error }).catch(() => {});
  });

  setupSocketListeners();
}

async function connectWithApiKey(apiKey, igUsername) {
  if (socket && socket.connected) {
    console.log('Socket already connected');
    return;
  }

  const baseUrl = await getBackendUrl();
  socket = io(baseUrl, {
    transports: ['websocket'],
  });

  socket.on('connect', () => {
    console.log('Socket connected:', socket.id);
    socket.emit('auth:apikey', { apiKey, ig_username: igUsername });
  });

  socket.on('auth:ok', ({ account_id, sender_id }) => {
    isAuthenticated = true;
    senderId = sender_id;
    console.log('Authenticated! account_id:', account_id, 'sender_id:', sender_id);
    chrome.storage.local.set({ senderId: sender_id });
    startHeartbeat();
    startReplyChecking();
    chrome.runtime.sendMessage({ type: 'SOCKET_STATUS', connected: true, auth: true }).catch(() => {});
  });

  socket.on('auth:error', ({ error }) => {
    isAuthenticated = false;
    senderId = null;
    console.error('Auth failed:', error);
    chrome.runtime.sendMessage({ type: 'SOCKET_STATUS', connected: true, auth: false, error }).catch(() => {});
  });

  setupSocketListeners();
}

function setupSocketListeners() {
  // Listen for ping from dashboard
  socket.on('ext:ping', (data) => {
    console.log('GOT PING:', data);
    chrome.storage.local.get('pingLog', ({ pingLog = [] }) => {
      pingLog.push({ ...data, receivedAt: Date.now() });
      if (pingLog.length > 20) pingLog = pingLog.slice(-20);
      chrome.storage.local.set({ pingLog });
    });
    chrome.runtime.sendMessage({ type: 'PING_RECEIVED', data }).catch(() => {});
  });

  // Listen for new tasks pushed via socket — send DM via content script API
  socket.on('task:new', (task) => {
    console.log('NEW TASK via socket:', task);

    // Ignore tasks not meant for this sender (safety check)
    if (task.sender_id && senderId && task.sender_id.toString() !== senderId.toString()) {
      console.log(`Task sender_id ${task.sender_id} doesn't match ours (${senderId}), ignoring`);
      return;
    }

    if (isProcessing) {
      console.log('Already processing a task, ignoring');
      return;
    }

    currentTask = task;
    isProcessing = true;
    const taskId = task._id || task.id;

    // Notify popup
    chrome.runtime.sendMessage({ type: 'TASK_RECEIVED', task }).catch(() => {});

    // Route task to appropriate handler based on type
    const taskHandler = task.type === 'comment_post'
      ? commentViaContentScript(task)
      : sendDMViaContentScript(task);
    taskHandler
      .then((result) => {
        handleTaskCompleted({ taskId, result }, () => {});
        chrome.runtime.sendMessage({
          type: 'LOG',
          data: { event: 'task_completed', taskId, target: task.target }
        });
      })
      .catch((err) => {
        console.error('DM failed:', err.message, '| errorType:', err.errorType);
        handleTaskFailed({
          taskId,
          error: err.message,
          errorType: err.errorType || 'UNKNOWN',
        }, () => {});
        chrome.runtime.sendMessage({
          type: 'LOG',
          data: { event: 'task_failed', taskId, error: err.message, errorType: err.errorType }
        });
      });
  });

  // Confirmation events
  socket.on('task:completed', (data) => {
    console.log('Task completed confirmation:', data);
  });

  socket.on('task:failed', (data) => {
    console.log('Task failed confirmation:', data);
  });

  // Campaign ETA — scheduler tells us when the next task is coming
  socket.on('campaign:eta', (data) => {
    console.log('Campaign ETA:', data);
    const eta = {
      nextAt: Date.now() + (data.nextInSeconds * 1000),
      pendingLeads: data.pendingLeads,
      campaignName: data.campaignName,
    };
    chrome.storage.local.set({ campaignEta: eta });
    chrome.runtime.sendMessage({ type: 'CAMPAIGN_ETA', ...eta }).catch(() => {});

    // Fallback: if we got campaign:eta but no task:new, poll for pending tasks.
    // This handles the case where emitToSender failed (socket mapping lost).
    if (!isProcessing && senderId) {
      setTimeout(() => pollForPendingTask(), 2000);
    }
  });

  socket.on('inbound:conversion', (data) => {
    console.log('Inbound conversion:', data);
    chrome.runtime.sendMessage({ type: 'INBOUND_CONVERSION', data }).catch(() => {});
  });

  socket.on('disconnect', () => {
    isAuthenticated = false;
    senderId = null;
    outboundAccount = null;
    stopHeartbeat();
    stopReplyChecking();
    console.log('Socket disconnected');
    chrome.runtime.sendMessage({ type: 'SOCKET_STATUS', connected: false, auth: false }).catch(() => {});
  });
}

// ============================================
// HEARTBEAT (every 15s, REST — survives socket drops)
// ============================================

function startHeartbeat() {
  stopHeartbeat();
  // Fire immediately, then every 15s
  doHeartbeat();
  heartbeatInterval = setInterval(doHeartbeat, 15000);
}

function stopHeartbeat() {
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
    heartbeatInterval = null;
  }
}

async function getAuthHeader() {
  const { token, apiKey } = await chrome.storage.local.get(['token', 'apiKey']);
  const key = token || apiKey;
  return key ? `Bearer ${key}` : null;
}

async function doHeartbeat() {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !senderId) return;
    const baseUrl = await getBackendUrl();
    const { testMode } = await chrome.storage.local.get('testMode');
    console.log('[Heartbeat] testMode from storage:', testMode, '→ sending:', !!testMode);

    await fetch(`${baseUrl}/api/sender-accounts/heartbeat`, {
      method: 'POST',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ sender_id: senderId, test_mode: !!testMode })
    });

    // Auto-poll for pending tasks on every heartbeat (fallback if websocket push failed)
    if (!isProcessing) {
      pollForPendingTask();
    }

    // Sync IG cookies to DB (throttled to every 5 minutes)
    syncCookies();

  } catch (error) {
    console.error('Heartbeat failed:', error);
  }
}

// ============================================
// TASK POLLING FALLBACK — picks up tasks if websocket push failed
// ============================================

async function pollForPendingTask() {
  if (isProcessing) return;

  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !senderId) return;

    const baseUrl = await getBackendUrl();
    const response = await fetch(`${baseUrl}/api/tasks/next?sender_id=${senderId}`, {
      method: 'GET',
      headers: { 'Authorization': authHeader, 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      console.log('[Poll] No tasks available (HTTP', response.status + ')');
      return;
    }

    const task = await response.json();
    if (!task || (!task._id && !task.id)) {
      console.log('[Poll] No pending tasks for this sender');
      return;
    }

    console.log('[Poll] Picked up pending task via polling:', task._id || task.id, '@' + task.target);

    // Process it the same way as a websocket-pushed task
    currentTask = task;
    isProcessing = true;
    const taskId = task._id || task.id;

    const pollHandler = task.type === 'comment_post'
      ? commentViaContentScript(task)
      : sendDMViaContentScript(task);
    pollHandler
      .then((result) => {
        handleTaskCompleted({ taskId, result }, () => {});
        chrome.runtime.sendMessage({
          type: 'LOG',
          data: { event: 'task_completed', taskId, target: task.target }
        });
      })
      .catch((err) => {
        console.error('[Poll] Task failed:', err.message, '| errorType:', err.errorType);
        handleTaskFailed({
          taskId,
          error: err.message,
          errorType: err.errorType || 'UNKNOWN',
        }, () => {});
      });
  } catch (err) {
    console.error('[Poll] Error:', err.message);
  }
}

// ============================================
// SEND DM VIA CONTENT SCRIPT (runs in IG page context)
// ============================================

// Find an Instagram tab with content script loaded and valid session.
// NEVER creates or reloads tabs — fails fast if nothing is available.
async function findIGTab() {
  const tabs = await chrome.tabs.query({ url: '*://*.instagram.com/*' });
  console.log(`[findIGTab] Found ${tabs.length} Instagram tab(s)`);

  // First pass: try to find a tab with content script already responding
  for (const tab of tabs) {
    try {
      const resp = await chrome.tabs.sendMessage(tab.id, { type: 'PING_CONTENT' });
      console.log(`[findIGTab] Tab ${tab.id} (${tab.url}):`, resp);
      if (resp?.alive && resp?.hasSession) {
        return tab.id;
      }
    } catch (e) {
      console.log(`[findIGTab] Tab ${tab.id} — content script not loaded:`, e.message);
    }
  }

  // Second pass: if no tab responded, refresh the first IG tab to re-inject content scripts
  // This handles extension reloads where old content scripts are orphaned
  if (tabs.length > 0) {
    const tab = tabs[0];
    console.log(`[findIGTab] No content script responded — refreshing tab ${tab.id} to re-inject`);
    await chrome.tabs.reload(tab.id);

    // Wait for tab to finish loading
    await new Promise((resolve) => {
      const onUpdated = (id, info) => {
        if (id === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); resolve(); }, 15000);
    });

    // Wait for react-hook.js to capture fiber tree + content.js to initialize
    await new Promise(r => setTimeout(r, 5000));

    // Try again
    try {
      const resp = await chrome.tabs.sendMessage(tab.id, { type: 'PING_CONTENT' });
      console.log(`[findIGTab] After refresh, tab ${tab.id}:`, resp);
      if (resp?.alive && resp?.hasSession) {
        return tab.id;
      }
    } catch (e) {
      console.log(`[findIGTab] After refresh, still no content script:`, e.message);
    }
  }

  return null;
}

async function sendDMViaContentScript(task) {
  console.log(`[DM] Routing DM for @${task.target} through content script (Lexical mode)`);

  const tabId = await findIGTab();
  if (!tabId) {
    throw Object.assign(
      new Error('No Instagram tab with valid session found. Make sure you are logged into Instagram.'),
      { errorType: 'SESSION_EXPIRED' }
    );
  }

  // Activate the tab without stealing window focus.
  // Lexical's editor.update() API works in background windows — no need to focus the window.
  // chrome.tabs.update(active:true) prevents Chrome's background-tab timer throttling.
  try {
    await chrome.tabs.update(tabId, { active: true });
    await new Promise(r => setTimeout(r, 500));
  } catch (e) {
    console.log('[DM] Could not activate tab:', e.message);
  }

  // Send task to content script — uses React fiber + Lexical editor to send DM
  let response = await sendToContentScript(tabId, { type: 'SEND_DM', task });

  // If content script says it needs navigation to /direct/, do it and retry
  if (!response.success && response.errorType === 'NAVIGATE_REQUIRED') {
    console.log('[DM] Tab not on /direct/, navigating and retrying...');
    await chrome.tabs.update(tabId, { url: 'https://www.instagram.com/direct/inbox/' });

    // Wait for page to finish loading
    await new Promise((resolve) => {
      const onUpdated = (id, info) => {
        if (id === tabId && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onUpdated);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(onUpdated);
      setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); resolve(); }, 15000);
    });

    // Extra wait for React to hydrate and react-hook.js to capture fiber tree
    await new Promise(r => setTimeout(r, 6000));

    // Retry
    response = await sendToContentScript(tabId, { type: 'SEND_DM', task });
  }

  // If DM failed and DOM fallback was used (needs window focus), retry with window focus
  if (!response.success && response.errorType !== 'NAVIGATE_REQUIRED' && response.errorType !== 'SESSION_EXPIRED') {
    console.log('[DM] First attempt failed, retrying with window focus...');
    try {
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await new Promise(r => setTimeout(r, 500));
    } catch (e) {
      console.log('[DM] Could not focus window for retry:', e.message);
    }
    response = await sendToContentScript(tabId, { type: 'SEND_DM', task });
  }

  if (response.success) {
    return response.result;
  }

  throw Object.assign(
    new Error(response.error || 'Content script DM failed'),
    { errorType: response.errorType || 'UNKNOWN' }
  );
}

async function commentViaContentScript(task) {
  console.log(`[Comment] Routing comment for @${task.target} through content script`);

  const tabId = await findIGTab();
  if (!tabId) {
    throw Object.assign(
      new Error('No Instagram tab with valid session found. Make sure you are logged into Instagram.'),
      { errorType: 'SESSION_EXPIRED' }
    );
  }

  // Activate the tab without stealing window focus
  try {
    await chrome.tabs.update(tabId, { active: true });
    await new Promise(r => setTimeout(r, 500));
  } catch (e) {
    console.log('[Comment] Could not activate tab:', e.message);
  }

  // Navigate to the user's profile
  await chrome.tabs.update(tabId, { url: `https://www.instagram.com/${task.target}/` });

  // Wait for page to finish loading
  await new Promise((resolve) => {
    const onUpdated = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(onUpdated); resolve(); }, 15000);
  });

  // Wait for React to hydrate + react-hook.js to load
  await new Promise(r => setTimeout(r, 8000));

  let response = await sendToContentScript(tabId, { type: 'COMMENT_POST', task });

  // If comment failed, retry with window focus (DOM fallback may need it)
  if (!response.success && response.errorType !== 'SESSION_EXPIRED') {
    console.log('[Comment] First attempt failed, retrying with window focus...');
    try {
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await new Promise(r => setTimeout(r, 500));
    } catch (e) {
      console.log('[Comment] Could not focus window for retry:', e.message);
    }
    response = await sendToContentScript(tabId, { type: 'COMMENT_POST', task });
  }

  if (response.success) {
    return response.result;
  }

  throw Object.assign(
    new Error(response.error || 'Content script comment failed'),
    { errorType: response.errorType || 'UNKNOWN' }
  );
}

function sendToContentScript(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: chrome.runtime.lastError.message, errorType: 'EXTENSION_ERROR' });
        return;
      }
      resolve(resp || { success: false, error: 'No response from content script', errorType: 'EXTENSION_ERROR' });
    });
  });
}

// ============================================
// PONG
// ============================================

function sendPong() {
  if (!socket || !isAuthenticated) {
    console.log('Not connected/authenticated, cannot send pong');
    return false;
  }
  socket.emit('ext:pong', {
    message: 'pong from extension',
    timestamp: Date.now(),
  });
  console.log('Pong sent!');
  return true;
}

// ============================================
// MESSAGE LISTENER
// ============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);

  switch (message.type) {
    case 'SEND_PONG':
      sendResponse({ success: sendPong() });
      break;

    case 'DM_LOG':
      console.log('[DM-Content]', message.step, message.detail || '');
      break;

    case 'CONNECT_SOCKET':
      connectSocket().then(() => sendResponse({ success: true }));
      return true;

    case 'GET_TASK':
      handleGetTask(sendResponse);
      return true;

    case 'TASK_COMPLETED':
      handleTaskCompleted(message.data, sendResponse);
      return true;

    case 'TASK_FAILED':
      handleTaskFailed(message.data, sendResponse);
      return true;

    case 'CAMPAIGN_NEXT':
      handleCampaignNext(sendResponse);
      return true;

    case 'CAMPAIGN_CONFIRM':
      handleCampaignConfirm(message.data, sendResponse);
      return true;

    case 'CAMPAIGN_SKIP':
      handleCampaignSkip(message.data, sendResponse);
      return true;

    case 'CAMPAIGN_AUTO_NEXT':
      handleCampaignAutoNext();
      sendResponse({ success: true });
      break;

    case 'CAMPAIGN_STOP_WAITING':
      if (waitTimer) { clearTimeout(waitTimer); waitTimer = null; }
      sendResponse({ success: true });
      break;

    case 'LOG':
      handleLog(message.data);
      break;

    case 'GET_STATUS':
      sendResponse({
        isProcessing,
        currentTask,
        socketConnected: socket?.connected || false,
        authenticated: isAuthenticated,
        senderId,
        outboundAccount,
        dailyLimit,
      });
      break;

    case 'SENDER_STATS':
      handleSenderStats(sendResponse);
      return true;

    case 'FOLLOWUPS_FETCH':
      handleFollowUpsFetch(message.data, sendResponse);
      return true;

    case 'FOLLOWUPS_STATS':
      handleFollowUpStats(sendResponse);
      return true;

    case 'FOLLOWUPS_UPDATE':
      handleFollowUpsUpdate(message.data, sendResponse);
      return true;

    case 'MARK_REPLIED':
      handleMarkReplied(message.data, sendResponse);
      return true;



  }
});

// ============================================
// TASK PICKUP (REST)
// ============================================

async function handleGetTask(sendResponse) {
  try {
    const authHeader = await getAuthHeader();

    if (!authHeader) {
      sendResponse({ success: false, error: 'No auth configured' });
      return;
    }

    if (!senderId) {
      sendResponse({ success: false, error: 'No sender_id (not authenticated yet)' });
      return;
    }



    const baseUrl = await getBackendUrl();
    const response = await fetch(`${baseUrl}/api/tasks/next?sender_id=${senderId}`, {
      method: 'GET',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const task = await response.json();

    if (task && (task._id || task.id)) {
      currentTask = task;
      isProcessing = true;
      sendResponse({ success: true, task });
    } else {
      sendResponse({ success: true, task: null });
    }

  } catch (error) {
    console.error('Error fetching task:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// ============================================
// TASK COMPLETE / FAIL (REST)
// ============================================

async function handleTaskCompleted(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    const taskId = data.taskId || data._id;
    const baseUrl = await getBackendUrl();

    await fetch(`${baseUrl}/api/tasks/${taskId}/complete`, {
      method: 'POST',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        result: { ...data.result, timestamp: new Date().toISOString() }
      })
    });

    currentTask = null;
    isProcessing = false;

    // Notify popup so it can update UI
    chrome.runtime.sendMessage({
      type: 'AUTO_SEND_COMPLETED',
      username: data.result?.username,
    }).catch(() => {});

    sendResponse({ success: true });

  } catch (error) {
    console.error('Error reporting task completion:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleTaskFailed(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    const taskId = data.taskId || data._id;
    const baseUrl = await getBackendUrl();

    await fetch(`${baseUrl}/api/tasks/${taskId}/failed`, {
      method: 'POST',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        error: data.error,
        errorType: data.errorType || 'UNKNOWN'
      })
    });

    currentTask = null;
    isProcessing = false;

    // Notify popup so it can update UI
    chrome.runtime.sendMessage({
      type: 'AUTO_SEND_FAILED',
      error: data.error,
      errorType: data.errorType,
    }).catch(() => {});

    sendResponse({ success: true });

  } catch (error) {
    console.error('Error reporting task failure:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// ============================================
// NOTIFICATIONS
// ============================================

function showNotification(title, message, data = {}) {
  const notifId = 'campaign_' + Date.now();
  chrome.notifications.create(notifId, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    priority: 2,
    requireInteraction: true,
  });
  // Store data so we can act on click
  chrome.storage.local.set({ [`notif_${notifId}`]: data });
}

chrome.notifications.onClicked.addListener((notifId) => {
  chrome.notifications.clear(notifId);
  // Focus or open Instagram tab
  chrome.tabs.query({ url: '*://*.instagram.com/*' }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: 'https://www.instagram.com/direct/inbox/' });
    }
  });
  // Notify popup that a notification was clicked
  chrome.runtime.sendMessage({ type: 'NOTIFICATION_CLICKED', notifId }).catch(() => {});
  // Clean up stored data
  chrome.storage.local.remove(`notif_${notifId}`);
});

// ============================================
// MANUAL CAMPAIGNS (REST)
// ============================================

async function handleCampaignNext(sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    const { testMode } = await chrome.storage.local.get('testMode');
    if (!authHeader || !senderId) {
      sendResponse({ success: false, error: 'Not authenticated' });
      return;
    }

    const baseUrl = await getBackendUrl();
    let url = `${baseUrl}/api/manual-campaigns/next?sender_id=${senderId}`;
    if (testMode) url += '&test_mode=true';

    const res = await fetch(url, {
      headers: { 'Authorization': authHeader }
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    sendResponse({ success: true, data });
  } catch (error) {
    console.error('Campaign next failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleCampaignConfirm(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    const baseUrl = await getBackendUrl();

    const res = await fetch(`${baseUrl}/api/manual-campaigns/confirm`, {
      method: 'POST',
      headers: { 'Authorization': authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        campaign_lead_id: data.campaignLeadId,
        sender_id: senderId,
      })
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Campaign confirm failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleCampaignSkip(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    const baseUrl = await getBackendUrl();

    const res = await fetch(`${baseUrl}/api/manual-campaigns/skip`, {
      method: 'POST',
      headers: { 'Authorization': authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        campaign_lead_id: data.campaignLeadId,
        reason: data.reason || 'Skipped by VA',
      })
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Campaign skip failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// ============================================
// AUTO-NEXT: wait out cooldown, then notify VA
// ============================================

async function handleCampaignAutoNext() {
  if (waitTimer) { clearTimeout(waitTimer); waitTimer = null; }

  try {
    const authHeader = await getAuthHeader();
    const { testMode } = await chrome.storage.local.get('testMode');
    if (!authHeader || !senderId) return;

    const baseUrl = await getBackendUrl();
    let url = `${baseUrl}/api/manual-campaigns/next?sender_id=${senderId}`;
    if (testMode) url += '&test_mode=true';

    const res = await fetch(url, { headers: { 'Authorization': authHeader } });
    if (!res.ok) return;

    const data = await res.json();

    if (data.status === 'lead') {
      // Lead is ready now — notify immediately
      showNotification(
        'Lead Ready',
        `@${data.lead.username} — ${data.lead.campaign_name}`,
        { lead: data.lead }
      );
      // Also forward to popup if open
      chrome.runtime.sendMessage({ type: 'CAMPAIGN_LEAD_READY', data }).catch(() => {});

    } else if (data.status === 'wait') {
      // Cooldown — wait it out, then retry
      const waitMs = (data.wait_seconds + 1) * 1000;
      console.log(`Cooldown: waiting ${data.wait_seconds}s for next lead`);
      chrome.runtime.sendMessage({
        type: 'CAMPAIGN_WAITING',
        wait_seconds: data.wait_seconds,
      }).catch(() => {});
      waitTimer = setTimeout(() => {
        waitTimer = null;
        handleCampaignAutoNext();
      }, waitMs);

    } else if (data.status === 'done') {
      showNotification('Campaign Complete', 'All leads have been processed.');
      chrome.runtime.sendMessage({ type: 'CAMPAIGN_DONE' }).catch(() => {});

    } else if (data.status === 'idle') {
      chrome.runtime.sendMessage({ type: 'CAMPAIGN_IDLE', reason: data.reason }).catch(() => {});
    }

  } catch (err) {
    console.error('Auto-next error:', err);
  }
}

// ============================================
// REPLY CHECKING (every 5 minutes)
// ============================================

let replyCheckInterval = null;

function startReplyChecking() {
  stopReplyChecking();
  // First check 30s after auth, then every 5 minutes
  replyCheckInterval = setTimeout(() => {
    doReplyCheck();
    replyCheckInterval = setInterval(doReplyCheck, 5 * 60 * 1000);
  }, 30000);
}

function stopReplyChecking() {
  if (replyCheckInterval) {
    clearInterval(replyCheckInterval);
    clearTimeout(replyCheckInterval);
    replyCheckInterval = null;
  }
}

async function doReplyCheck() {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !senderId) return;

    const baseUrl = await getBackendUrl();

    // Step 1: Get pending reply checks from server
    const res = await fetch(`${baseUrl}/api/reply-checks/pending?limit=20`, {
      headers: { 'Authorization': authHeader },
    });

    if (!res.ok) {
      console.error('[ReplyCheck] Failed to get pending:', res.status);
      return;
    }

    const { leads } = await res.json();
    if (!leads || leads.length === 0) {
      console.log('[ReplyCheck] No threads to check');
      return;
    }

    console.log(`[ReplyCheck] Checking ${leads.length} thread(s)`);

    // Step 2: Route through content script to check IG threads
    const tabId = await findIGTab();
    if (!tabId) {
      console.log('[ReplyCheck] No IG tab with session — skipping');
      return;
    }

    const threads = leads.map(l => ({
      lead_id: l._id,
      thread_id: l.ig_thread_id,
      username: l.username,
    }));

    const response = await new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { type: 'CHECK_REPLIES', threads }, (resp) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(resp);
      });
    });

    if (!response?.success || !response.results) {
      console.error('[ReplyCheck] Content script error:', response?.error);
      return;
    }

    // Step 3: Report results back to server
    const withReplies = response.results.filter(r => r.has_reply);
    if (withReplies.length === 0) {
      console.log('[ReplyCheck] No new replies detected');
      return;
    }

    console.log(`[ReplyCheck] Found ${withReplies.length} new reply(s)!`);

    await fetch(`${baseUrl}/api/reply-checks/results`, {
      method: 'POST',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ results: withReplies }),
    });

    console.log('[ReplyCheck] Results reported to server');

  } catch (err) {
    console.error('[ReplyCheck] Error:', err.message);
  }
}

// ============================================
// COOKIE SYNC (every 5 minutes, piggybacked on heartbeat)
// ============================================

let lastCookieSync = 0;
const COOKIE_SYNC_INTERVAL = 5 * 60 * 1000; // 5 minutes

async function syncCookies() {
  if (Date.now() - lastCookieSync < COOKIE_SYNC_INTERVAL) return;

  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !outboundAccount?._id) return;

    const cookies = await chrome.cookies.getAll({ domain: '.instagram.com' });
    if (!cookies || cookies.length === 0) return;

    const baseUrl = await getBackendUrl();
    const res = await fetch(`${baseUrl}/api/outbound-accounts/me/cookies`, {
      method: 'PUT',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ cookies }),
    });

    if (res.ok) {
      lastCookieSync = Date.now();
      console.log(`[CookieSync] Saved ${cookies.length} cookies for @${outboundAccount.username}`);
    } else {
      console.error('[CookieSync] Server returned', res.status);
    }
  } catch (err) {
    console.error('[CookieSync] Error:', err.message);
  }
}

// ============================================
// FOLLOW-UPS (REST)
// ============================================

async function handleSenderStats(sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !senderId) {
      sendResponse({ success: false, error: 'Not authenticated' });
      return;
    }
    const baseUrl = await getBackendUrl();
    const res = await fetch(`${baseUrl}/api/manual-campaigns/sender-stats?sender_id=${senderId}`, {
      headers: { 'Authorization': authHeader },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Sender stats fetch failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleFollowUpsFetch(data, sendResponse) {
  try {
    data = data || {};
    const authHeader = await getAuthHeader();
    if (!authHeader || !outboundAccount?._id) {
      sendResponse({ success: false, error: 'Not authenticated or no outbound account' });
      return;
    }
    const baseUrl = await getBackendUrl();
    const params = new URLSearchParams({
      outbound_account_id: outboundAccount._id,
      page: data.page || 1,
      limit: data.limit || 20,
    });
    if (data.status && data.status !== 'all') params.set('status', data.status);
    if (data.search) params.set('search', data.search);
    if (data.sort) params.set('sort', data.sort);

    const res = await fetch(`${baseUrl}/api/follow-ups?${params}`, {
      headers: { 'Authorization': authHeader },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Follow-ups fetch failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleFollowUpStats(sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader || !outboundAccount?._id) {
      sendResponse({ success: false, error: 'Not authenticated' });
      return;
    }
    const baseUrl = await getBackendUrl();
    const res = await fetch(`${baseUrl}/api/follow-ups/stats?outbound_account_id=${outboundAccount._id}`, {
      headers: { 'Authorization': authHeader },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Follow-up stats fetch failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleFollowUpsUpdate(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader) {
      sendResponse({ success: false, error: 'Not authenticated' });
      return;
    }
    const baseUrl = await getBackendUrl();
    const res = await fetch(`${baseUrl}/api/follow-ups/${data.id}`, {
      method: 'PATCH',
      headers: { 'Authorization': authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: data.status,
        note: data.note,
        follow_up_date: data.follow_up_date,
      }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Follow-up update failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

async function handleMarkReplied(data, sendResponse) {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader) {
      sendResponse({ success: false, error: 'Not authenticated' });
      return;
    }
    const baseUrl = await getBackendUrl();
    const res = await fetch(`${baseUrl}/outbound-leads/mark-replied`, {
      method: 'POST',
      headers: { 'Authorization': authHeader, 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: data.username }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `HTTP ${res.status}`);
    }
    const result = await res.json();
    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('Mark replied failed:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// ============================================
// LOGGING (REST)
// ============================================

async function handleLog(data) {
  try {
    const authHeader = await getAuthHeader();
    if (!authHeader) return;
    const baseUrl = await getBackendUrl();

    await fetch(`${baseUrl}/api/logs`, {
      method: 'POST',
      headers: {
        'Authorization': authHeader,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ...data,
        timestamp: Date.now()
      })
    });
  } catch (error) {
    console.error('Error logging to backend:', error);
  }
}

// ============================================
// DM ASSISTANT — relay scraped conversation to backend for AI suggestion
// ============================================

// ============================================
// STARTUP + CONFIG CHANGE
// ============================================

// Restore critical state from storage on service worker restart
chrome.storage.local.get(['senderId', 'outboundAccount', 'dailyLimit'], (data) => {
  if (data.senderId && !senderId) senderId = data.senderId;
  if (data.outboundAccount && !outboundAccount) outboundAccount = data.outboundAccount;
  if (data.dailyLimit !== undefined && dailyLimit === null) dailyLimit = data.dailyLimit;
});

connectSocket();

chrome.storage.onChanged.addListener((changes) => {
  if (changes.token || changes.apiKey || changes.igUsername || changes.backendUrl) {
    stopHeartbeat();
    senderId = null;
    outboundAccount = null;
    if (socket) socket.disconnect();
    connectSocket();
  }
});

console.log('Background service worker initialized');
