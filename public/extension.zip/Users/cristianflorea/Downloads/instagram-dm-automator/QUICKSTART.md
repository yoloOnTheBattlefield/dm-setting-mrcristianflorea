# 🚀 Quick Start Guide

## 5-Minute Setup

### 1. Backend Setup (2 minutes)

```bash
# Install dependencies
npm install

# Start server
npm start
```

You should see:
```
🚀 Instagram DM Automation Backend
📡 Server running on http://localhost:3000
🔑 API Key: your-secret-key-123
```

### 2. Extension Setup (2 minutes)

1. Open Chrome
2. Go to `chrome://extensions/`
3. Enable "Developer mode" (top right)
4. Click "Load unpacked"
5. Select this folder
6. ✅ Extension installed!

### 3. Configure (1 minute)

1. Click extension icon in toolbar
2. Enter:
   - **Backend URL:** `http://localhost:3000/api`
   - **API Key:** `your-secret-key-123`
3. Click "Save Configuration"

### 4. Test It!

**Quick Test - Manual Send:**
1. Open Instagram.com
2. Click extension icon
3. Enter:
   - Username: `any_instagram_user`
   - Message: `Hi {{username}}, this is a test!`
4. Click "Send Now"
5. Watch the magic happen! 🎉

**Backend Test - Automated Tasks:**

Create a task using cURL:
```bash
curl -X POST http://localhost:3000/api/tasks \
  -H "Authorization: Bearer your-secret-key-123" \
  -H "Content-Type: application/json" \
  -d '{
    "type": "send_dm",
    "target": "example_user",
    "message": "Hi {{username}}!"
  }'
```

Then:
1. Go to Instagram.com
2. Click extension → "Check for Tasks"
3. Task will execute automatically!

---

## Troubleshooting

**❌ "No API key configured"**
→ Click extension icon → ⚙️ Configuration → Enter API key

**❌ "Please open Instagram in the current tab"**
→ Make sure you're on instagram.com

**❌ Backend connection failed**
→ Check backend is running: `npm start`

**❌ Element not found errors**
→ Instagram changed their layout. Update selectors in `content.js`

---

## Next Steps

### Add More Tasks
```bash
# Create multiple tasks
for user in user1 user2 user3; do
  curl -X POST http://localhost:3000/api/tasks \
    -H "Authorization: Bearer your-secret-key-123" \
    -H "Content-Type: application/json" \
    -d "{
      \"type\": \"send_dm\",
      \"target\": \"$user\",
      \"message\": \"Hi {{username}}!\"
    }"
done
```

### View All Tasks
```bash
curl http://localhost:3000/api/tasks \
  -H "Authorization: Bearer your-secret-key-123"
```

### View Logs
```bash
curl http://localhost:3000/api/logs \
  -H "Authorization: Bearer your-secret-key-123"
```

---

## Production Checklist

Before deploying to production:

- [ ] Change API key from default
- [ ] Use environment variables for secrets
- [ ] Add database (PostgreSQL/MongoDB)
- [ ] Implement rate limiting
- [ ] Add user authentication
- [ ] Use HTTPS
- [ ] Add error monitoring (Sentry)
- [ ] Create backup system
- [ ] Add logging service
- [ ] Write unit tests
- [ ] Document API with Swagger
- [ ] Set up CI/CD pipeline

---

## ⚠️ Important Notes

1. **Instagram TOS:** This violates Instagram's Terms of Service
2. **Account Risk:** Your account may be banned
3. **Rate Limits:** Don't send too many messages too fast
4. **Testing:** Always test with test accounts first
5. **Ethics:** Don't spam people. Be respectful.

---

## Need Help?

1. Check console logs (F12 in Chrome)
2. Check backend terminal output
3. Read the full README.md
4. Verify Instagram structure hasn't changed

Happy automating! 🎉
