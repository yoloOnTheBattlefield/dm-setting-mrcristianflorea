// injected.js — Tricks Instagram into thinking the tab is always visible/focused.
// This allows DM sending to work even when the tab is in the background.
// Injected at document_start via content script so it runs before IG's JS.
{
  // Override requestAnimationFrame to work in background tabs
  window.requestAnimationFrame = (cb) => { setTimeout(() => cb?.(performance.now()), 0); };
  window.requestIdleCallback = (cb) => { cb?.({}); };

  // Always report page as visible
  Object.defineProperty(document, 'visibilityState', { get() { return 'visible'; } });
  Object.defineProperty(document, 'webkitVisibilityState', { get() { return 'visible'; } });
  Object.defineProperty(document, 'hidden', { get() { return false; } });
  Object.defineProperty(document, 'webkitHidden', { get() { return false; } });

  // Always report document as focused
  Object.defineProperty(document, 'hasFocus', { get() { return () => true; } });
  Document.prototype.hasFocus = new Proxy(Document.prototype.hasFocus, {
    apply(target, thisArg, args) { return true; }
  });

  // Block visibility change events
  const block = (e) => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
  document.addEventListener('visibilitychange', block, true);
  document.addEventListener('webkitvisibilitychange', block, true);
  window.addEventListener('pagehide', block, true);

  // Block blur/focus events on document/window so IG doesn't pause
  const blockIfGlobal = (e) => {
    if (e.target === document || e.target === window) {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    }
  };
  document.addEventListener('blur', blockIfGlobal, true);
  window.addEventListener('blur', blockIfGlobal, true);
  document.addEventListener('focus', blockIfGlobal, true);
  window.addEventListener('focus', blockIfGlobal, true);
  window.addEventListener('mouseleave', blockIfGlobal, true);
}
