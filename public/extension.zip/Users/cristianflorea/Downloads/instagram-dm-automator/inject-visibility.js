// inject-visibility.js — DISABLED
// The visibility hack was causing Instagram to detect automation and log users out.
// API-based DM sending via fetch() works fine without it, even in background tabs.
// Keeping this file as a no-op so the manifest content_scripts entry doesn't error.
